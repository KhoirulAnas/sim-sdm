<?php

	class Employee_model extends CI_Model{


	function __consturct(){
	parent::__construct();
	
	}

	public function getarea(){
	$query = $this->db->get('master_area');
	$result = $query->result();
	return $result;
	}
  public function pencarian_d($jk){
    $this->db->where("k_jk",$jk);
    
    return $this->db->get("master_kar");
    } 
  public function getfilter(){
  $query = $this->db->get('master_kar');
  $result = $query->result();
  return $result;
  }
  public function getsat(){
  $query = $this->db->get('master_satuan');
  $result = $query->result();
  return $result;
  }
  public function getkota(){
  $query = $this->db->get('inf_lokasi');
  $result = $query->result();
  return $result;
  }
  public function getpddkn(){
  $query = $this->db->get('master_pendidikan');
  $result = $query->result();
  return $result;
  }
  public function getpddknv(){
  $query = $this->db->get('master_riwayat_pddkn');
  $result = $query->result();
  return $result;
  }
  public function nikahedit(){
  $query = $this->db->get('master_riwayat_nikah');
  $result = $query->result();
  return $result;
  }
  public function suamiistri(){
  $query = $this->db->get('master_suamiistri');
  $result = $query->result();
  return $result;
  }
  public function ortu(){
  $query = $this->db->get('master_anak');
  $result = $query->result();
  return $result;
  }
  public function getpanggol(){
  $query = $this->db->get('master_pangkat_golongan');
  $result = $query->result();
  return $result;
  }
  public function getjenjab(){
  $query = $this->db->get('master_jenis_jabatan');
  $result = $query->result();
  return $result;
  }
  public function getjk(){
  $query = $this->db->get('master_gender');
  $result = $query->result();
  return $result;
  }
  public function getagama(){
  $query = $this->db->get('master_agama');
  $result = $query->result();
  return $result;
  }
    public function getdepartment(){
	$query = $this->db->get('master_area');
	$result = $query->result();
	return $result;
	}
    public function emselect(){
    $sql = "SELECT * FROM `master_kar` WHERE `k_stakepeg`='Aktif'";
    $query=$this->db->query($sql);
  	$result = $query->result();
  	return $result;
	}
  public function emselect2(){
    $sql = "SELECT * FROM `master_kar` WHERE `k_stakepeg`='Aktif' AND `k_unit_kerja`='UPT BALAI LATIHAN KERJA DI BOJONEGORO'";
    $query=$this->db->query($sql);
    $result = $query->result();
    return $result;
  }
   public function pensiun(){
    $sql = "SELECT * FROM `master_kar`";
    $query=$this->db->query($sql);
    $result = $query->result();
    return $result;
  }
    public function emselectByID($emid){
    $sql = "SELECT * FROM `employee`
      WHERE `em_id`='$emid'";
    $query=$this->db->query($sql);
	$result = $query->row();
	return $result;
	}
    public function emselectByCode($emid){
    $sql = "SELECT * FROM `employee`
      WHERE `em_code`='$emid'";
    $query=$this->db->query($sql);
	$result = $query->row();
	return $result;
	}
    public function getInvalidUser(){
      $sql = "SELECT * FROM `master_kar`";
        $query=$this->db->query($sql);
		$result = $query->result();
		return $result;
	}
    public function Does_email_exists($k_nip_baru) {
		$user = $this->db->dbprefix('master_kar');
        $sql = "SELECT `k_nip_baru` FROM $user
		WHERE `k_nip_baru`='$k_nip_baru'";
		$result=$this->db->query($sql);
        if ($result->row()) {
            return $result->row();
        } else {
            return false;
        }
    }
    public function Add($data){
        $this->db->insert('master_kar',$data);
    }
    public function GetBasics($id){
      $sql = "SELECT `master_kar`.*,`master_area`.*
      FROM `master_kar`
      LEFT JOIN `master_area` ON `master_kar`.`k_unit_kerja`=`master_area`.`area_nama`
      WHERE `k_nip_baru`='$id' AND `k_stakepeg`='Aktif'";

    $query=$this->db->query($sql);
    $result = $query->row();
    return $result;          
    
    }
    public function GetPend2($id){
      $sql = "SELECT `master_riwayat_pddkn`.*,`master_pendidikan`.*
      FROM `master_riwayat_pddkn`
      LEFT JOIN `master_pendidikan` ON `master_riwayat_pddkn`.`jenjang`=`master_pendidikan`.`pend_jenjang`
      WHERE `k_nip_baru`='$id'";

    $query=$this->db->query($sql);
    $result = $query->row();
    return $result;          
    }
    public function GetBasic($id){
      $sql = "SELECT `employee`.*,
      `designation`.*,
        `department`.*
      FROM `employee`
      LEFT JOIN `designation` ON `employee`.`des_id`=`designation`.`id`
      LEFT JOIN `department` ON `employee`.`dep_id`=`department`.`id`
      WHERE `em_id`='$id'";
      /*$sql = "SELECT `master_kar`.*, `master_pendidikan`.*, `master_riwayat_nikah`.*
      FROM `master_kar`
      LEFT JOIN `master_pendidikan` ON `master_kar`.`pend_id`=`master_pendidikan`.`pend_id`
      LEFT JOIN `master_riwayat_nikah` ON `master_kar`.`mrn_id`=`master_riwayat_nikah`.`mrn_id`
      WHERE `k_id`='$id'";*/
        $query=$this->db->query($sql);
		$result = $query->row();
		return $result;          
    }
    public function ProjectEmployee($id){
      $sql = "SELECT `assign_task`.`assign_user`,
      `employee`.`em_id`,`first_name`,`last_name`
      FROM `assign_task`
      LEFT JOIN `employee` ON `assign_task`.`assign_user`=`employee`.`em_id`
      WHERE `assign_task`.`project_id`='$id' AND `user_type`='Team Head'";
      $query=$this->db->query($sql);
      $result = $query->result();
      return $result;          
    }
    public function GetBankInfo($id){
      $sql = "SELECT * FROM `master_riwayat_nikah`
      WHERE `k_nip_baru`='$id'";
        $query=$this->db->query($sql);
		$result = $query->row();
		return $result;          
    }
    public function GetpreAddress($id){
      $sql = "SELECT * FROM `master_riwayat_nikah`
      WHERE `mrn_id`='$id' ";
        $query=$this->db->query($sql);
		$result = $query->row();
		return $result;          
    }
    public function GetEducation($id){
      $sql = "SELECT * FROM `master_pendidikan`
      WHERE `k_id`='$id'";
        $query=$this->db->query($sql);
		$result = $query->result();
		return $result;          
    }
    public function GetExperience($id){
      $sql = "SELECT * FROM `master_suamiistri`
      WHERE `k_nip_baru`='$id'";
        $query=$this->db->query($sql);
		$result = $query->result();
		return $result;          
    }
    
    public function GetAllEmployee(){
      $sql = "SELECT * FROM `employee`";
        $query=$this->db->query($sql);
		$result = $query->result();
		return $result;          
    }
    public function desciplinaryfetch(){
      $sql = "SELECT `desciplinary`.*,
      `employee`.`em_id`,`first_name`,`last_name`,`em_code`
      FROM `desciplinary`
      LEFT JOIN `employee` ON `desciplinary`.`em_id`=`employee`.`em_id`";
        $query=$this->db->query($sql);
		$result = $query->result();
		return $result;        
    }
    public function GetLeaveiNfo($id,$year){
      $sql = "SELECT `assign_leave`.*,
      `leave_types`.`name`
      FROM `assign_leave`
      LEFT JOIN `leave_types` ON `assign_leave`.`type_id`=`leave_types`.`type_id`
      WHERE `assign_leave`.`emp_id`='$id' AND `dateyear`='$year'";
        $query=$this->db->query($sql);
		$result = $query->result();
		return $result;        
    }
    public function GetsalaryValue($id){
      $sql = "SELECT `emp_salary`.*,
      `addition`.*,
      `deduction`.*,
      `salary_type`.*
      FROM `emp_salary`
      LEFT JOIN `addition` ON `emp_salary`.`id`=`addition`.`salary_id`
      LEFT JOIN `deduction` ON `emp_salary`.`id`=`deduction`.`salary_id`
      LEFT JOIN `salary_type` ON `emp_salary`.`type_id`=`salary_type`.`id`
      WHERE `emp_salary`.`emp_id`='$id'";
        $query=$this->db->query($sql);
		$result = $query->row();
		return $result;        
    }
    public function Update($data,$id){
		$this->db->where('k_nip_baru', $id);
		$this->db->update('master_kar',$data);        
    }
    public function Update_Education($id,$data){
		$this->db->where('id', $id);
		$this->db->update('education',$data);        
    }
    public function Update_Department($id,$data){
    $this->db->where('area_id', $id);
    $this->db->update('master_area',$data);        
    }
    public function Edit_Anak($id,$data){
    $this->db->where('id', $id);
    $this->db->update('master_anak',$data);        
    }
    public function edit_pddkn($id,$data){
    $this->db->where('id', $id);
    $this->db->update('master_riwayat_pddkn',$data);        
    }
    public function Edit_Nikah($id,$data){
		$this->db->where('mrn_id', $id);
		$this->db->update('master_riwayat_nikah',$data);        
    }
    public function UpdateParmanent_Address($id,$data){
		$this->db->where('id', $id);
		$this->db->update('address',$data);        
    }
    public function Reset_Password($id,$data){
		$this->db->where('k_nip_baru', $id);
		$this->db->update('master_kar',$data);        
    }
    public function Update_Experience($id,$data){
		$this->db->where('id', $id);
		$this->db->update('master_suamiistri',$data);        
    }
    public function Update_Salary($sid,$data){
		$this->db->where('id', $sid);
		$this->db->update('emp_salary',$data);        
    }
    public function Update_Deduction($did,$data){
		$this->db->where('de_id', $did);
		$this->db->update('deduction',$data);        
    }
    public function Update_Addition($aid,$data){
		$this->db->where('addi_id', $aid);
		$this->db->update('addition',$data);        
    }
    public function Update_Desciplinary($id,$data){
		$this->db->where('id', $id);
		$this->db->update('desciplinary',$data);        
    }
    public function Update_Media($id,$data){
		$this->db->where('id', $id);
		$this->db->update('social_media',$data);        
    }
    public function AddParmanent_Address($data){
        $this->db->insert('address',$data);
    } 
    public function Add_education($data){
        $this->db->insert('master_pendidikan',$data);
    }
    public function Add_Experience($data){
        $this->db->insert('master_suamiistri',$data);
    }
    public function Add_Desciplinary($data){
        $this->db->insert('desciplinary',$data);
    }
    public function Add_BankInfo($data){
        $this->db->insert('master_riwayat_nikah',$data);
    }
    public function GetEmployeeId($id){
        $sql = "SELECT `k_pass` FROM `master_kar` WHERE `k_nip_baru`='$id'";
        $query = $this->db->query($sql);
        $result = $query->row();
        return $result; 
    }
    public function GetFileInfo($id){
        $sql = "SELECT * FROM `master_suamiistri` WHERE `k_nip_baru`='$id'";
        $query = $this->db->query($sql);
        $result = $query->result();
        return $result; 
    }
    public function GetAnak($id){
        $sql = "SELECT * FROM `master_anak` WHERE `k_nip_baru`='$id'";
        $query = $this->db->query($sql);
        $result = $query->result();
        return $result; 
    }
    public function GetPend($id){
        $sql = "SELECT * FROM `master_riwayat_pddkn` WHERE `k_nip_baru`='$id'";
        $query = $this->db->query($sql);
        $result = $query->result();
        return $result; 
    }
        
    public function Getsuamiistri($id){
        $sql = "SELECT * FROM `master_suamiistri` WHERE `k_nip_baru`='$id'";
        $query = $this->db->query($sql);
        $result = $query->result();
        return $result; 
    }

    public function GetNikah($id){
        $sql = "SELECT * FROM `master_riwayat_nikah` WHERE `k_nip_baru`='$id' ";
        $query = $this->db->query($sql);
        $result = $query->result();
        return $result; 
    }
    public function GetSocialValue($id){
        $sql = "SELECT * FROM `social_media` WHERE `emp_id`='$id'";
        $query = $this->db->query($sql);
        $result = $query->row();
        return $result; 
    }
    public function GetEduValue($id){
        $sql = "SELECT * FROM `master_pendidikan` WHERE `id`='$id'";
        $query = $this->db->query($sql);
        $result = $query->row();
        return $result; 
    }
    public function GetSuamiistriValue($id){
        $sql = "SELECT * FROM `master_suamiistri` WHERE `id`='$id'";
        $query = $this->db->query($sql);
        $result = $query->result();
        return $result; 
    }
    public function GetAnakValue($id){
        $sql = "SELECT * FROM `master_anak` WHERE `id`='$id'";
        $query = $this->db->query($sql);
        $result = $query->row();
        return $result; 
    }
    public function GetPddknValue($id){
        $sql = "SELECT * FROM `master_riwayat_pddkn` WHERE `id`='$id'";
        $query = $this->db->query($sql);
        $result = $query->row();
        return $result; 
    }
    public function GetNikahValue($id){
        $sql = "SELECT * FROM `master_riwayat_nikah` WHERE `mrn_id`='$id'";
        $query = $this->db->query($sql);
        $result = $query->row();
        return $result; 
    }
    public function GetUptValue($id){
        $sql = "SELECT * FROM `master_area` WHERE `area_id`='$id'";
        $query = $this->db->query($sql);
        $result = $query->row();
        return $result; 
    }
    public function GetExpValue($id){
        $sql = "SELECT * FROM `master_suamiistri` WHERE `id`='$id'";
        $query = $this->db->query($sql);
        $result = $query->row();
        return $result; 
    }
    public function GetDesValue($id){
        $sql = "SELECT * FROM `desciplinary` WHERE `id`='$id'";
        $query = $this->db->query($sql);
        $result = $query->row();
        return $result; 
    } 
	public function depselect(){
  	$query = $this->db->get('master_area');
  	$result = $query->result();
  	return $result;
	}
    public function Add_Department($data){
    $this->db->insert('master_area',$data);
  }

    public function Add_Designation($data){
      $this->db->insert('designation',$data);
    }
    public function File_Upload($data){
    $this->db->insert('master_suamiistri',$data);
  }
  public function Anak_Upload($data){
    $this->db->insert('master_anak',$data);
  }
  public function save_pddkn($data){
    $this->db->insert('master_riwayat_pddkn',$data);
  }
  public function Nikah_Upload($data){
    $this->db->insert('master_riwayat_nikah',$data);
  }
    public function Add_Salary($data){
    $this->db->insert('emp_salary',$data);
  }
    public function Add_Addition($data1){
    $this->db->insert('addition',$data1);
  }
    public function Add_Deduction($data2){
    $this->db->insert('deduction',$data2);
  }
    public function Add_Assign_Leave($data){
    $this->db->insert('assign_leave',$data);
  }
    public function Insert_Media($data){
    $this->db->insert('social_media',$data);
  }
    public function desselect(){
  	$query = $this->db->get('designation');
  	$result = $query->result();
  	return $result;
	}
    public function DeletEdu($id){
      $this->db->delete('master_pendidikan',array('id'=> $id));
  }
    public function DeletEXP($id){
      $this->db->delete('master_suamiistri',array('id'=> $id));
  }
    public function DeletDisiplinary($id){
      $this->db->delete('desciplinary',array('id'=> $id));
  }        
  public function suamiistri_delete($id){
        $this->db->delete('master_suamiistri',array('id'=> $id));
    }
    public function anak_delete($id){
        $this->db->delete('master_anak',array('id'=> $id));
    }
    public function nikah_delete($id){
        $this->db->delete('master_riwayat_nikah',array('mrn_id'=> $id));
    }
    public function pddkn_delete($id){
        $this->db->delete('master_riwayat_pddkn',array('id'=> $id));
    }
    public function pencarian_upt($k_unit_kerja){
    $this->db->where("k_unit_kerja",$k_unit_kerja);
    return $this->db->get("master_kar");
    } 
    }
?>