        <?php $this->load->view('backend/header'); ?>
<?php $this->load->view('backend/sidebar'); ?>
         <br><br>
                     <div class="page-wrapper">
                     <div class="message"></div>
            
            <div class="row page-titles">
                <div class="col-md-5 align-self-center">
                    
                    <h3 class="text-themecolor"><i class="fa fa-user-secret" style="color:#1976d2"></i> <?php echo $basics->k_nama; ?></h3>
                </div>
                <div class="col-md-7 align-self-center">
                    <ol class="breadcrumb">
                                 
                    </ol>
                </div>
            </div>
               <?php $areavalue = $this->employee_model->getarea(); ?> 
               <?php $satvalue = $this->employee_model->getsat(); ?> 
               <?php $jkvalue = $this->employee_model->getjk(); ?> 
               <?php $agamavalue = $this->employee_model->getagama(); ?> 
               <?php $kotavalue = $this->employee_model->getkota(); ?> 
               <?php $pendidikanvalue = $this->employee_model->getpddkn(); ?> 
               <?php $golvalue = $this->employee_model->getpanggol(); ?>  
               <?php $jenjabvalue = $this->employee_model->getjenjab(); ?>

             
                <?php $depvalue = $this->employee_model->getdepartment(); ?>
            
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12 col-xlg-12 col-md-12">
                        <div class="card">
                            <!-- Nav tabs -->
                            <ul class="nav nav-tabs profile-tab" role="tablist">
                                <div id="tombol_biodata"><li class="nav-item"> <a class="nav-link active" data-toggle="tab" href="#home" role="tab" style="font-size: 14px;">  BIODATA </a> </li></div>
                               
                                <div id="tombol_change2"><li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#nikah" role="tab" style="font-size: 14px;"> Riwayat Pernikahan </a> </li></div>
                                <div id="tombol_change3"><li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#suamiistri" role="tab" style="font-size: 14px;"> Riwayat Suami/Istri</a> </li></div>
                                <div id="tombol_change4"><li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#anak" role="tab" style="font-size: 14px;"> Orang Tua</a> </li></div>
                              <div id="tombol_change5"><li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#pendidikan" role="tab" style="font-size: 14px;"> Riwayat Pendidikan </a> </li></div>
                                
                                <!---- <li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#document" role="tab" style="font-size: 14px;"> Posisi SKPD</a> </li>
                                <li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#salary" role="tab" style="font-size: 14px;"> Asal Kepegawaian</a> </li>
                                <li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#leave" role="tab" style="font-size: 14px;"> Jenis Kepegawaian</a> </li>
                                <li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#social" role="tab" style="font-size: 14px;"> Kedudukan Hukum Pegawai</a> </li>
                                <li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#social" role="tab" style="font-size: 14px;"> CPNS/PNS/Pangkat</a> </li>
                                <li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#social" role="tab" style="font-size: 14px;"> Jenis Jabatan</a> </li>
                                
                                <li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#" role="tab" style="font-size: 14px;"> Riwayat Pendidikan</a> </li>
                              --->  
                                <div id="tombol_change"><li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#password" role="tab" style="font-size: 14px;"> Ubah Kata Sandi</a> </li></div>
                                    
                                
                            </ul>
                            <!-- Tab panes -->

                            <div class="tab-content">
                                <div class="tab-pane active" id="home" role="tabpanel">
                                    <div class="card">
				                        <div class="card-body">
                                            <div class="row">
                                                <div class="col-md-4">
                        <div class="card">
                            <div class="card-body">
                                <center class="m-t-30">
                            <?php if(!empty($basics->k_foto)){ ?>
                                    <img src="<?php echo base_url(); ?>assets/images/users/<?php echo $basics->k_foto; ?>" class="img-circle" width="150" />
                                    <?php } else { ?>
                                    <img src="<?php echo base_url(); ?>assets/images/users/user.png" class="img-circle" width="150" alt="<?php echo $basics->k_nama ?>" title="<?php echo $basics->k_nama ?>"/>                                   
                                    <?php } ?>       
                                    <h4 class="card-title m-t-10"><?php echo $basics->k_nama; ?></h4>
                                </center>
                            </div>
                            <div>
                                <hr> </div>
                            
                            <div class="card-body"> <small class="text-muted">Tanggal Lahir </small>
                                <h5><?php echo $basics->k_tglahir; ?></h5> <small class="text-muted p-t-30 db">NIK</small>
                                <h5><?php echo $basics->k_nik; ?></h5> <small class="text-muted p-t-30 db">Alamat</small>
                                <h5><?php echo $basics->k_alamat; ?></h5>
                                
                            </div>
                        </div>                                                    
                                                </div>
                                                <div class="col-md-8">
				                                
                                                <form class="row" action="Update" method="post" enctype="multipart/form-data">
				                                    
				                                    <div class="form-group col-md-10 m-t-10">
                                                        <label>Nama Lengkap</label>
                                                        <input type="text" class="form-control form-control-line" placeholder="k_nama" name="k_nama" value="<?php echo $basics->k_nama; ?>" minlength="3" required> 
                                                    </div><br>

                                                    <div class="form-group col-md-6 m-t-10">
                                                        <label>NIK </label>
                                                        <input type="text"   class="form-control form-control-line" placeholder="" name="k_nik" value="<?php echo $basics->k_nik; ?>" required > 
                                                    </div>
                                                    <br>
                                                    
                                                    <div class="form-group col-md-10 m-t-10">
                                                        <label>NIP </label>
                                                        <input type="text"    class="form-control form-control-line" placeholder="" name="k_nip" value="<?php echo $basics->k_nip_baru; ?>" required > 
                                                    </div>
                                                    
				                        <br>

                                                    <div class="form-group col-md-10 m-t-10">
                                        
                                        <label>Tempat Lahir </label>
                                        <select name="tlahir" value="<?php echo $basics->k_tglahir; ?>"   class="form-control custom-select" required>
                                            <option><?php echo $basics->k_tlahir; ?></option>
                                            <?Php foreach($kotavalue as $value): ?>
                                            <option value="<?php echo $value->lokasi_nama ?>"><?php echo $value->lokasi_nama ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                        <br>
                                        <div class="form-group col-md-10 m-t-10">
                                        <label>SATUAN AREA</label>
                                        <select id="sat" name="sat" value="<?php echo $basics->k_satuan; ?>"  class="form-control custom-select">
                                            <?Php foreach($satvalue as $value): ?>
                                            <option value="<?php echo $value->satuan_kode ?>"><?php echo $value->satuan_nama ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div> 
                                        <br>
                                        <div class="form-group col-md-10 m-t-10">
                                        <label>AREA UPT </label>
                                        <select id="area" name="upt" value="<?php echo $basics->k_unit_kerja; ?>"  class="form-control custom-select">
                                            <?Php foreach($areavalue as $value): 
                                                if($value->area_sat_kode==$basics->k_satuan):
                                                ?>
                                            <option value="<?php echo $value->area_nama ?>"><?php echo $value->area_nama ?></option>
                                            <?php 
                                        endif;
                                        endforeach; ?>
                                        </select>
                                    </div>                
				                    <br>
                                    <div class="form-group col-md-5 m-t-10">
                                        <label>Jenis Kelamin</label>
                                        <select name="jk" value="<?php echo $basics->k_jk; ?>" class="form-control custom-select" required>
                                            
                                            <option>
                                                <?php if($basics->k_jk=='1'){echo 'Laki-Laki';}
                                                    else echo "Perempuan"; ?>
                                            </option>
                                            <?Php foreach($jkvalue as $value): ?>
                                            
                                            <option value="<?php echo $value->mg_id ?>"><?php echo $value->mg_nama ?></option>
                                            
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                        
                                    <div class="form-group col-md-5 m-t-10">
                                        <label>Agama</label>
                                        <select name="agm" value="<?php echo $basics->k_agama; ?>" class="form-control custom-select" required>
                                            <option><?php if($basics->k_agama=='1'){echo 'Islam';}
                                                    else if($basics->k_agama=='2'){echo 'Katholik';} 
                                                    else if($basics->k_agama=='3'){echo 'Kristen Protestan';}
                                                    else if($basics->k_agama=='4'){echo 'Hindu';}
                                                    else if($basics->k_agama=='5'){echo 'Budha';}
                                                    else if($basics->k_agama=='6'){echo 'Kong Hu Cu';}
                                                    else if($basics->k_agama=='7'){echo 'Lainnya';}
                                                    ?></option>
                                            <?Php foreach($agamavalue as $value): ?>
                                            <option value="<?php echo $value->ma_id ?>"><?php echo $value->ma_nama ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                    <br>
                                    <div class="form-group col-md-10 m-t-10">
                                        <label>Status Nikah</label>
                                        <select name="snikah" value="<?php echo $basics->k_snikah; ?>" class="form-control custom-select" required>
                                            <option><?php echo $basics->k_snikah; ?></option>
                                            <option value="Menikah">Menikah</option>
                                            <option value="Belum Menikah">Belum Menikah</option>
                                            
                                        </select>
                                    </div>

                                    <br>
                                    <div class="form-group col-md-10 m-t-10">
                                        <label>Alamat</label>
                                        <input type="text" name="alamat" value="<?php echo $basics->k_alamat; ?>"  class="form-control form-control-line" placeholder="Masukkan Alamat lengkap.." minlength="2" required> 
                                    </div>

                                        <br>
                                    <div class="form-group col-md-4 m-t-10">
                                        <label>Pangkat Golongan</label>
                                        <select name="panggol" value="<?php echo $basics->k_golongan; ?>" class="form-control custom-select" required>
                                            <option><?php if($basics->k_golongan=='1'){echo ' Pembina Utama IV/e';}
                                            else if($basics->k_golongan=='2'){echo 'Pembina Utama Madya IV/d';}
                                            else if($basics->k_golongan=='3'){echo 'Pembina Utama Muda iv/C';}
                                            else if($basics->k_golongan=='4'){echo 'Pembina Tk. I IV/b';}
                                            else if($basics->k_golongan=='5'){echo 'Pembina IV/a';}
                                            else if($basics->k_golongan=='6'){echo 'Penata Tk. I III/D';}
                                            else if($basics->k_golongan=='7'){echo 'Penata III/c';}
                                            else if($basics->k_golongan=='8'){echo 'Penata Muda Tk. I III/b';}
                                            else if($basics->k_golongan=='9'){echo 'Penata Muda III/a';}
                                            else if($basics->k_golongan=='10'){echo 'Pengatur Tk. I II/d';}
                                            else if($basics->k_golongan=='11'){echo 'Pengatur II/c';}
                                            else if($basics->k_golongan=='12'){echo 'Pengatur Muda Tk. I II/b';}
                                            else if($basics->k_golongan=='13'){echo 'Pengatur Muda II/a';}
                                            else if($basics->k_golongan=='14'){echo 'Juru Tk. I I/d';}
                                            else if($basics->k_golongan=='15'){echo 'Juru I/c';}
                                            else if($basics->k_golongan=='16'){echo 'Juru Muda Tk. I I/b';}
                                            else if($basics->k_golongan=='17'){echo 'Juru Muda I/b';}
                                                    ?></option>
                                            <?Php foreach($golvalue as $value): ?>
                                            <option value="<?php echo $value->panggol_id ?>"><?php echo $value->panggol_pangkat ?> <b>(<?php echo $value->panggol_golru ?>)</b></option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                    
                                    <div class="form-group col-md-4 m-t-10">
                                        <label>Jenis Jabatan</label>
                                        <select name="jenjab" value="<?php echo $basics->k_jenis_jabatan; ?>"  class="form-control custom-select" required>
                                            <option><?php if($basics->k_jenis_jabatan=='1'){echo 'Jabatan Struktural';}
                                            else if($basics->k_jenis_jabatan=='2'){echo 'Jabatan Fungsional';}
                                            else if($basics->k_jenis_jabatan=='3'){echo 'Jabatan Pelaksana';}
                                                    ?></option>
                                            <?Php foreach($jenjabvalue as $value): ?>
                                            <option value="<?php echo $value->jenjab_id ?>"><?php echo $value->jenjab_nama ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                    <br>
                                    <!-- <div class="form-group col-md-10 m-t-10">
                                        <label>Hak Akses</label>
                                        <select name="akses" value="<?php echo $basics->k_akses; ?>"  class="form-control custom-select" required>
                                            <option><?php if($basics->k_akses=='ADMIN'){echo 'Fasilitator';}
                                                    else if($basics->k_akses=='EMPLOYEE'){echo 'Pegawai';}?></option>
                                            <option value="ADMIN">FASILITATOR</option>
                                            <option value="EMPLOYEE">PEGAWAI</option>
                                            
                                        </select>
                                    </div> -->
                                    <div class="form-group col-md-4 m-t-10">
                                        <label>Tanggal Lahir </label>
                                        <input type="date" name="tl" value="<?php echo $basics->k_tglahir; ?>" id="example-email2" class="form-control" placeholder="" required> 
                                    </div>

                                    <div class="form-group col-md-4 m-t-10">
                                        <label>TMT Jabatan </label>
                                        <input type="date" name="tmtj" value="<?php echo $basics->k_tmt_jabatan; ?>"  id="example-email2" class="form-control" placeholder="" required> 
                                    </div>

                                    <div class="form-group col-md-4 m-t-10">
                                        <label>TMT Pensiun </label>
                                        <input type="date" name="tmtp" value="<?php echo $basics->k_tmt_pensiun; ?>"  id="example-email2" class="form-control" placeholder="" required> 
                                    </div>
                                    
                                    <div class="form-group col-md-12 m-t-10">
                                   <?php if(!empty($basics->k_foto)){ ?>
                                    <img src="<?php echo base_url(); ?>assets/images/users/<?php echo $basics->k_foto; ?>" class="img-circle" width="150" />
                                    <?php } else { ?>
                                    <img src="<?php echo base_url(); ?>assets/images/users/user.png" class="img-circle" width="150" alt="<?php echo $basics->k_nama ?>" title="<?php echo $basics->k_nama ?>"/>                                   
                                    <?php } ?>
                                                        <label>    </label>
                                                        <input type="file" <?php if($this->session->userdata('user_type')=='EMPLOYEE'){ ?> readonly <?php } ?> name="image_url" class="form-control" value=""> 
                                                    </div>
                                                    
				                                    
                                                    <div class="form-actions col-md-12">
                                                        <input type="hidden" name="k_nip_baru" value="<?php echo $basics->k_nip_baru; ?>">
                                                        <button type="submit" class="btn btn-info"> <i class="fa fa-check"></i> Simpan</button>
                                                        <a href="<?php base_url();?>employees"><button type="button" class="btn btn-info">Batal</button></a>
                                                    </div>
                                                    
				                                </form>
                                                </div>
                                        </div>
				                        </div>
                                    </div>
                                </div>
                                <!--second tab-->

<div class="tab-pane" id="nikah" role="tabpanel">
                    <div class="card-body">
                        <button data-toggle="modal" data-target="#modal_nikah" type="button" class="btn btn-primary"><i class="fa fa-plus"></i> Tambah Data</button> <i>Klik Tambah Data untuk menambahkan Data Pernikahan</i>
                        <br>
                        <div class="modal fade" id="modal_nikah" style="margin-top: 50px;" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
      <div class="modal-content">
          
          <div class="modal-footer">
            <button class="btn btn-default btn-sm" type="button" data-dismiss="modal"><i class="fa fa-close fa-fw"></i> Close</button>
          </div>
          <div class="modal-body">
            

  
    <center><h3 class="box-title">Form Tambah Data</h3></center>
  
<div class="card-body">

                                        <form class="row" action="Add_Nikah" method="post" enctype="multipart/form-data">
                                            
                                            <div class="form-group col-md-12 m-t-12">
                                                <label class="">Nomor Surat</label>
                                                <input type="text" name="no" class="form-control" required="" aria-invalid="false"  required>
                                            </div>
                                            <div class="form-group col-md-12 m-t-12">
                                                <label class="">Status</label>
                                                <input type="text" name="status" class="form-control" required="" aria-invalid="false" minlength="5" required>
                                            </div>
                                            
                                          <div class="form-group col-md-12 m-t-12">
                                        <label>Tanggal Nikah </label>
                                        <input type="date" name="tn"  id="example-email2" class="form-control" placeholder="" required> 
                                    </div> 
                                        <div class="form-group col-md-12 m-t-12">
                                                <label class="">Surat Nikah</label>
                                                <input type="file" name="file_url" class="form-control" required="" aria-invalid="false" required>
                                            </div>
                                            <div class="form-group col-md-12 m-t-12">
                                                    <input type="hidden" name="k_nip_baru" value="<?php echo $basics->k_nip_baru; ?>">          
                                                                                             
                                                        <button type="submit" class="btn btn-info pull-right"> <i class="fa fa-check"></i> Simpan</button>
                                                    </div>

                                      </form>
                                    </div>                
</div>

            </div>
          </div>
          
      </div>
  
                    <br>
                    <div class="table-responsive ">
                        <table id="example213" class="table table-hover table-striped" cellspacing="0" width="100%">
                            <thead>
                                <tr>
                                    <th>ID </th>
                                    <th>Nomor surat</th>
                                    <th>Status</th>
                                    <th>Tanggal Nikah</th>
                                    <th>Surat Nikah</th>
                                    <th>Status Persetujuan</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tfoot>
                                <tr>
                                    <th>ID </th>
                                    <th>Nomor surat</th>
                                    <th>Status</th>
                                    <th>Tanggal Nikah</th> 
                                    <th>Surat Nikah</th>
                                    <th>Status Persetujuan</th>
                                    <th>Aksi</th>
                                </tr>
                            </tfoot>
                            <tbody>
                               <?php foreach($nikah as $value): ?>
                                <tr>
                                    <td><?php echo $value->mrn_id ?></td>
                                    <td><?php echo $value->mrn_no_surat ?></td>
                                    <td><?php echo $value->mrn_status ?></td>
                                    <td><?php echo $value->mrn_tgl_nikah ?></td>
                                    
                                    <td>
                                   
                                        <a href="<?php echo base_url(); ?>assets/images/users/<?php echo $value->file_url ?>" target="_blank"><img src="<?php echo base_url(); ?>assets/images/docs.png" width="30px"></a>
                                     
                                        <a href="#" title="Edit" class="experience21" data-id="<?php echo $value->mrn_id ?>">Ubah Berkas</i></a></td>
                                    <td><?php if($value->approval=='belum disetujui'){echo "<span style='font-size:10;' class='label label-warning'>Belum Disetujui</span>";}
                                    else if($value->approval=='telah disetujui'){echo "<span style='font-size:10;' class='label label-info'>Telah Disetujui</span>";}
                                    else if($value->approval=='tidak disetujui'){echo "<span style='font-size:10;' class='label label-danger'>Tidak Disetujui</span>";}
                                    ?></td>
                                    <td>
                                        
                                        <a href="#" title="Edit" class="btn btn-sm btn-info waves-effect waves-light experience2" data-id="<?php echo $value->mrn_id ?>"><i class="fa fa-pencil-square-o"></i></a>
                                        <a onclick="return confirm('Apa anda yakin akan menghapus data?')"  href="<?php echo base_url();?>employee/nikah_delete/<?php echo $value->mrn_id;?>" title="Delete" class="btn btn-sm btn-info waves-effect waves-light"><i class="fa fa-trash-o"></i></a>
                                     
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>      
                                </div>


  <div class="tab-pane" id="suamiistri" role="tabpanel">
                    <div class="card-body">
                                    <button data-toggle="modal" data-target="#modal_suamiistri" type="button" class="btn btn-primary"><i class="fa fa-plus"></i> Tambah Data</button> <i>Klik Tambah Data untuk menambahkan Data Pasangan</i>
                        <br>
                        <div class="modal fade" id="modal_suamiistri" style="margin-top: 50px;" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
      <div class="modal-content">
          
          <div class="modal-footer">
            <button class="btn btn-default btn-sm" type="button" data-dismiss="modal"><i class="fa fa-close fa-fw"></i> Close</button>
          </div>
          <div class="modal-body">
            

  
    <center><h3 class="box-title">Form Tambah Data</h3></center>
  
 <div class="card-body">
                                        <form class="row" action="Add_File" method="post" enctype="multipart/form-data">
                                    
                                            <div class="form-group col-md-12 m-t-12">
                                                <label class="">Nama</label>
                                                <input type="text" name="pas_nama"  class="form-control" required="" aria-invalid="false" minlength="5" required>
                                            </div>
                                            <div class="form-group col-md-12 m-t-12">
                                                <label class="">NIK</label>
                                                <input type="text" name="pas_nik" class="form-control" required="" aria-invalid="false" minlength="5" required>
                                            </div>
                                            <div class="form-group col-md-12 m-t-12">
                                        <label>Status</label>
                                        <select name="pas_stat"class="form-control custom-select" required>
                                            <option>Pilih</option>
                                            
                                            <option value="suami">Suami</option>
                                            <option value="istri">Istri</option>
                                        </select>
                                    </div>
                                                <div class="form-group col-md-12 m-t-12">
                                        
                                        <label>Tempat Lahir </label>
                                        <select name="pas_tmpt" class="form-control custom-select" required>
                                            <option>Pilih</option>
                                            <?Php foreach($kotavalue as $value): ?>
                                            <option value="<?php echo $value->lokasi_nama ?>"><?php echo $value->lokasi_nama ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>

                                            <div class="form-group col-md-12 m-t-12">
                                                <label class="">Tanggal Lahir</label>
                                                <input type="date" name="pas_tgl"  class="form-control" required="" aria-invalid="false" minlength="5" required>
                                            </div> 
                                            <div class="form-group col-md-12 m-t-12">
                                                <label class="">Pekerjaan</label>
                                                <input type="text" name="pas_pek"  class="form-control" required="" aria-invalid="false" minlength="5" required>
                                            </div>
                                            <div class="form-group col-md-12 m-t-12">
                                                <label class="">Instansi</label>
                                                <input type="text" name="pas_instansi"  class="form-control" aria-invalid="false" minlength="5" required>
                                            </div>
                                            <div class="form-group col-md-12 m-t-12">
                                                <label class="">Akta Kelahiran</label>
                                                <input type="file" name="file_url"  class="form-control" required="" aria-invalid="false" required>
                                            </div>
                                            
                                            <div class="form-group col-md-12 m-t-12">
                                                    <input type="hidden" name="k_nip_baru" value="<?php echo $basics->k_nip_baru; ?>">          
                                                                                             
                                                        <button type="submit" class="btn btn-info pull-right"> <i class="fa fa-check"></i> Simpan</button>
                                                    </div>
                                            
                                        </form>
                                    </div>
</div>

            </div>
          </div>
          
      </div>
                    <br>
                    <div class="table-responsive ">
                        <table id="example213" class="table table-hover table-striped" cellspacing="0" width="100%">
                            <thead>
                                <tr>
                                    <th>ID </th>
                                    <th>Nama Pasangan</th>
                                    <th>NIK</th>
                                    <th>Status</th>
                                    <th>Tempat Lahir</th>
                                    <th>Tanggal Lahir</th>
                                    <th>Pekerjaan</th>
                                    <th>Instansi</th>
                                    <th>Akta Kelahiran</th>
                                    <th>Status Persetujuan</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tfoot>
                                <tr>
                                    <th>ID </th>
                                    <th>Nama Pasangan</th>
                                    <th>NIK</th>
                                    <th>Status</th>
                                    <th>Tempat Lahir</th>
                                    <th>Tanggal Lahir</th>
                                    <th>Pekerjaan</th>
                                    <th>Instansi</th>
                                    <th>Akta Kelahiran</th>
                                    <th>Status Persetujuan</th>
                                    <th>Aksi</th>
                                </tr>
                            </tfoot>
                            <tbody>
                               <?php foreach($fileinfo as $value): ?>
                                <tr>
                                    <td><?php echo $value->id ?></td>
                                    
                                    <td><?php echo $value->pas_nama ?></td>
                                    <td><?php echo $value->pas_nik ?></td>
                                    <td><?php echo $value->pas_stat ?></td>
                                    <td><?php echo $value->pas_tmpt ?></td>
                                    <td><?php echo $value->pas_tgl ?></td>
                                    <td><?php echo $value->pas_pek ?></td>
                                    <td><?php echo $value->pas_instansi ?></td>
                                    <td><a href="<?php echo base_url(); ?>assets/images/users/<?php echo $value->file_url ?>" target="_blank"><img src="<?php echo base_url(); ?>assets/images/docs.png" width="30px"></a>
                                    
                                    <a href="#" title="Edit" class="experience22" data-id="<?php echo $value->id ?>">Ubah Berkas</i></a></td>
                                    </td>
                                    <td><?php if($value->approval=='belum disetujui'){echo "<span style='font-size:10;' class='label label-warning'>Belum Disetujui</span>";}
                                    else if($value->approval=='telah disetujui'){echo "<span style='font-size:10;' class='label label-info'>Telah Disetujui</span>";}
                                    else if($value->approval=='tidak disetujui'){echo "<span style='font-size:10;' class='label label-danger'>Tidak Disetujui</span>";}
                                    ?></td>
                                    <td>
                                         
                                        <a href="#" title="Edit" class="btn btn-sm btn-info waves-effect waves-light experience" data-id="<?php echo $value->id ?>"><i class="fa fa-pencil-square-o"></i></a>
                                        <a onclick="return confirm('Apa anda yakin akan menghapus data?')"  href="<?php echo base_url();?>employee/suamiistri_delete/<?php echo $value->id;?>" title="Delete" class="btn btn-sm btn-info waves-effect waves-light"><i class="fa fa-trash-o"></i></a>
                                    
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>                                    
                                   
                                </div>

<div class="tab-pane" id="anak" role="tabpanel">
                                    <div class="card-body">
                                <button data-toggle="modal" data-target="#modal_anak" type="button" class="btn btn-primary"><i class="fa fa-plus"></i> Tambah Data</button> <i>Klik Tambah Data untuk menambahkan Data Orang Tua</i>
                        <br>
                        <div class="modal fade" id="modal_anak" style="margin-top: 50px;" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
      <div class="modal-content">
          
          <div class="modal-footer">
            <button class="btn btn-default btn-sm" type="button" data-dismiss="modal"><i class="fa fa-close fa-fw"></i> Close</button>
          </div>
          <div class="modal-body">
            

  
    <center><h3 class="box-title">Form Tambah Data</h3></center>
  
 <div class="card-body">
                                        <form class="row" action="Add_Anak" method="post" enctype="multipart/form-data">
                                             
                                            <div class="form-group col-md-12 m-t-12">
                                                <label class="">Nama</label>
                                                <input type="text" name="nama"  class="form-control" required="" aria-invalid="false"  required>
                                            </div>
                                            <div class="form-group col-md-12 m-t-12">
                                                <label class="">NIK</label>
                                                <input type="text" name="nik" class="form-control" required="" aria-invalid="false" minlength="5" required>
                                            </div>
                                            <div class="form-group col-md-12 m-t-12">
                                        <label>Status</label>
                                          <input type="text" name="stat" class="form-control" required="" aria-invalid="false" required>
                                    </div>
                                                <div class="form-group col-md-12 m-t-12">
                                        
                                        <label>Tempat Lahir </label>
                                        <select name="tmpt"  class="form-control custom-select" required>
                                            <option>Pilih</option>
                                            <?Php foreach($kotavalue as $value): ?>
                                            <option value="<?php echo $value->lokasi_nama ?>"><?php echo $value->lokasi_nama ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                            <div class="form-group col-md-12 m-t-12">
                                                <label class="">Pekerjaan</label>
                                                <input type="text" name="pek"  class="form-control" required="" aria-invalid="false" minlength="5" required>
                                            </div>
                                            <div class="form-group col-md-12 m-t-12">
                                                <label class="">Akta Kelahiran</label>
                                                <input type="file" name="file_url"class="form-control" required="" aria-invalid="false" required>
                                            </div>
                                            

                                            <div class="form-group col-md-12 m-t-12">
                                                
                                                    <input type="hidden" name="k_nip_baru" value="<?php echo $basics->k_nip_baru; ?>">                                                   
                                                    <button type="submit" class="btn btn-success">Simpan</button>
                                                
                                            </div>
                                            
                                        </form>
                                    </div>
</div>

            </div>
          </div>
          
      </div>
                    <br>
                    <div class="table-responsive ">
                        <table id="example213" class="table table-hover table-striped" cellspacing="0" width="100%">
                            <thead>
                                <tr>
                                    <th>ID </th>
                                    <th>Nama Ortu</th>
                                    <th>NIK</th>
                                    <th>Status</th>
                                    <th>Tempat Lahir</th>
                                    <th>Pekerjaan</th>
                                    <th>Akta Kelahiran</th>
                                    <th>Status Persetujuan</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tfoot>
                                <tr>
                                    <th>ID </th>
                                    <th>Nama Ortu</th>
                                    <th>NIK</th>
                                    <th>Status</th>
                                    <th>Tempat Lahir</th>
                                    <th>Pekerjaan</th>
                                    <th>Akta Kelahiran</th>
                                    <th>Status Persetujuan</th>
                                    <th>Aksi</th>
                                </tr>
                            </tfoot>
                            <tbody>
                               <?php foreach($anak as $value): ?>
                                <tr>
                                    <td><?php echo $value->id ?></td>
                                    <td><?php echo $value->an_nama ?></td>
                                    <td><?php echo $value->an_nik ?></td>
                                    <td><?php echo $value->an_stat ?></td>
                                    <td><?php echo $value->an_tlahir ?></td>
                                    <td><?php echo $value->an_pek ?></td>
                                    <td><a href="<?php echo base_url(); ?>assets/images/users/<?php echo $value->file_url ?>" target="_blank"><img src="<?php echo base_url(); ?>assets/images/docs.png" width="30px"></a>
                                    
                                    <a href="#" title="Edit" class="experience23" data-id="<?php echo $value->id ?>">Ubah Berkas</i></a>
                                    </td>
                                    <td><?php if($value->approval=='belum disetujui'){echo "<span style='font-size:10;' class='label label-warning'>Belum Disetujui</span>";}
                                    else if($value->approval=='telah disetujui'){echo "<span style='font-size:10;' class='label label-info'>Telah Disetujui</span>";}
                                    else if($value->approval=='tidak disetujui'){echo "<span style='font-size:10;' class='label label-danger'>Tidak Disetujui</span>";}
                                    ?></td>
                                    <td>
                                             
                                    <a href="#" title="Edit" class="btn btn-sm btn-info waves-effect waves-light education" data-id="<?php echo $value->id ?>"><i class="fa fa-pencil-square-o"></i></a>
                                        
                                        <a onclick="return confirm('Apa anda yakin akan menghapus data?')"  href="<?php echo base_url();?>employee/anak_delete/<?php echo $value->id;?>" title="Delete" class="btn btn-sm btn-info waves-effect waves-light"><i class="fa fa-trash-o"></i></a>
                                    
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>      
                                   
                                </div>


<div class="tab-pane" id="pendidikan" role="tabpanel">
                                    <div class="card-body">
                                <button data-toggle="modal" data-target="#modal_pddkn" type="button" class="btn btn-primary"><i class="fa fa-plus"></i> Tambah Data</button> <i>Klik Tambah Data untuk menambahkan Data Pendidikan</i>
                        <br>
                        <div class="modal fade" id="modal_pddkn" style="margin-top: 50px;" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
      <div class="modal-content">
          
          <div class="modal-footer">
            <button class="btn btn-default btn-sm" type="button" data-dismiss="modal"><i class="fa fa-close fa-fw"></i> Close</button>
          </div>
          <div class="modal-body">
            

  
    <center><h3 class="box-title">Form Tambah Data</h3></center>
  
<div class="card-body">
                                        <form class="row" action="Add_pddkn" method="post" enctype="multipart/form-data">
                                             
                                            <div class="form-group col-md-12 m-t-12">
                                                <label class="">Jenjang Pendidikan</label>
                                                
                                        <select name="jenjang" value="" class="form-control custom-select" required>
                                            <option>pilih</option>
                                            <?Php foreach($pendidikanvalue as $value): ?>
                                            <option value="<?php echo $value->pend_jenjang ?>"><?php echo $value->pend_jenjang ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                            </div>
                                            <div class="form-group col-md-12 m-t-12">
                                                <label class="">Nama Institusi</label>
                                                <input type="text" name="nama" class="form-control" required="" aria-invalid="false" minlength="5" required>
                                            </div>
                                            <div class="form-group col-md-12 m-t-12">
                                                <label class="">Tahun Masuk</label>
                                                <input type="date" name="thn_masuk" class="form-control" required="" aria-invalid="false" minlength="5" required>
                                            </div>
                                        <div class="form-group col-md-12 m-t-12">
                                                <label class="">Tahun Lulus</label>
                                                <input type="date" name="thn_lulus" class="form-control" required="" aria-invalid="false" minlength="5" required>
                                            </div>
                                            <div class="form-group col-md-12 m-t-12">
                                                <label class="">File</label>
                                                <input type="file" name="file_url" class="form-control" required="" aria-invalid="false" required>
                                            </div>

                                        <div class="form-actions col-md-12">
                                                    <input type="hidden" name="approval" value="belum disetujui">       
                                                    <input type="hidden" name="k_nip_baru" value="<?php echo $basics->k_nip_baru; ?>">                                                   
                                                        <button type="submit" class="btn btn-info pull-right"> <i class="fa fa-check"></i> Simpan</button>
                                                    </div>
                                        </form>
                                    </div>
</div>

            </div>
          </div>
          
      </div>
                    <br>
                    <div class="table-responsive ">
                        <table id="example213" class="table table-hover table-striped" cellspacing="0" width="100%">
                            <thead>
                                <tr>
                                    <th>ID </th>
                                    <th>Jenjang</th>
                                    <th>Nama Institusi</th>
                                    <th>Tahun Masuk</th>
                                    <th>Tahun Lulus</th>
                                    <th>Ijazah</th>
                                    <th>Status Persetujuan</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tfoot>
                                <tr>
                                    <th>ID </th>
                                    <th>Jenjang</th>
                                    <th>Nama Institusi</th>
                                    <th>Tahun Masuk</th>
                                    <th>Tahun Lulus</th>
                                    <th>Ijazah</th>
                                    <th>Status Persetujuan</th>
                                    <th>Aksi</th>
                                </tr>
                            </tfoot>
                            <tbody>
                  
                               <?php foreach($pendidikan as $value): ?>
                                <tr>
                                    <td><?php echo $value->id ?></td>
                                    <td><?php echo $value->jenjang ?></td>
                                    <td><?php echo $value->nama ?></td>
                                    <td><?php echo $value->thn_masuk ?></td>
                                    <td><?php echo $value->thn_lulus ?></td>
                                    <td>

                                        <a href="<?php echo base_url(); ?>assets/images/users/<?php echo $value->file_url ?>" target="_blank"><img src="<?php echo base_url(); ?>assets/images/docs.png" width="30px"></a>
                                    <a href="#" title="Edit" class="experience24" data-id="<?php echo $value->id ?>">Ubah Berkas</i></a>
                                    </td>
                                    
                                    <td>
                                        
                                    <a href="#" title="Edit" class="btn btn-sm btn-info waves-effect waves-light education2" data-id="<?php echo $value->id ?>"><i class="fa fa-pencil-square-o"></i></a>
                                        
                                        <a onclick="return confirm('Apa anda yakin akan menghapus data?')"  href="<?php echo base_url();?>employee/pddkn_delete/<?php echo $value->id;?>" title="Delete" class="btn btn-sm btn-info waves-effect waves-light"><i class="fa fa-trash-o"></i></a>
                                    
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>                                    
                               

                                    
                                </div>

<div class="tab-pane" id="password" role="tabpanel">
                                    <div class="card-body">
                                                <form class="row" action="Reset_Password" method="post" enctype="multipart/form-data">
                                                    
                                                    <div class="form-group col-md-6 m-t-20">
                                                        <label>Password</label>
                                                        <input type="password" class="form-control" name="new1" value="" required> 
                                                    </div>
                                                    <div class="form-group col-md-6 m-t-20">
                                                        <label>Ulang Password</label>
                                                        <input type="password" id="" name="new2" class="form-control " required> 
                                                    </div>
                                                    <div class="form-actions col-md-12">
                                                    <input type="hidden" name="k_nip_baru" value="<?php echo $basics->k_nip_baru; ?>">                                                   
                                                        <button type="submit" class="btn btn-info pull-right"> <i class="fa fa-check"></i> Simpan</button>
                                                    </div>
                                                </form>
                                    </div>
                                </div>

                                    <?php if($this->session->userdata('user_type')=='ADMIN'){ ?>
                                                    <?php } else { ?>


<div class="" id="nikah2" role="tabpanel">
                                    <div class="card-body">
                    <div class="table-responsive ">

                    <h2><div class="text-black" style="">Riwayat Pernikahan</h2>
                        <table id="example213" class="table table-hover table-striped" cellspacing="0" width="100%">
                            <thead>
                                <tr>
                                    <th>ID </th>
                                    <th>Nomor surat</th>
                                    <th>Status</th>
                                    <th>Tanggal Nikah</th>
                                    <th>File</th>
                                    
                                </tr>
                            </thead>
                            <tfoot>
                                <tr>
                                    <th>ID </th>
                                    <th>Nomor surat</th>
                                    <th>Status</th>
                                    <th>Tanggal Nikah</th> 
                                    <th>File</th>
                                    
                                </tr>
                            </tfoot>
                            <tbody>
                               <?php foreach($nikah as $value): ?>
                                <tr>
                                    <td><?php echo $value->mrn_id ?></td>
                                    <td><?php echo $value->mrn_no_surat ?></td>
                                    <td><?php echo $value->mrn_status ?></td>
                                    <td><?php echo $value->mrn_tgl_nikah ?></td>
                                    <td>
                                   
                                        <a href="<?php echo base_url(); ?>assets/images/users/<?php echo $value->file_url ?>" target="_blank"><img src="<?php echo base_url(); ?>assets/images/docs.png" width="30px"></a>
                                        <?php if($this->session->userdata('user_type')=='EMPLOYEE'){ ?>
                                                    <?php } else { ?>
                                        <a href="#" title="Edit" class="experience21" data-id="<?php echo $value->mrn_id ?>">Ubah Berkas</i></a></td>
                                    <td>
                                        
                                        <a href="#" title="Edit" class="btn btn-sm btn-info waves-effect waves-light experience2" data-id="<?php echo $value->mrn_id ?>"><i class="fa fa-pencil-square-o"></i></a>
                                        <a onclick="return confirm('Apa anda yakin akan menghapus data?')"  href="<?php echo base_url();?>employee/nikah_delete/<?php echo $value->mrn_id;?>" title="Delete" class="btn btn-sm btn-info waves-effect waves-light"><i class="fa fa-trash-o"></i></a>
                                     <?php } ?>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>      
                                   
                                </div>


  <div class="" id="suamiistri2" role="tabpanel">
                                    <div class="card-body">
                    <h2><div class="text-black" style="">Riwayat Suami Istri</h2>
                    <div class="table-responsive ">
                        <table id="example213" class="table table-hover table-striped" cellspacing="0" width="100%">
                            <thead>
                                <tr>
                                    <th>ID </th>
                                    <th>Nama Pasangan</th>
                                    <th>NIK</th>
                                    <th>Status</th>
                                    <th>Tempat Lahir</th>
                                    <th>Tanggal Lahir</th>
                                    <th>Pekerjaan</th>
                                    <th>Instansi</th>
                                    <th>File</th>
                                    
                                </tr>
                            </thead>
                            <tfoot>
                                <tr>
                                    <th>ID </th>
                                    <th>Nama Pasangan</th>
                                    <th>NIK</th>
                                    <th>Status</th>
                                    <th>Tempat Lahir</th>
                                    <th>Tanggal Lahir</th>
                                    <th>Pekerjaan</th>
                                    <th>Instansi</th>
                                    <th>File</th>
                                    
                                </tr>
                            </tfoot>
                            <tbody>
                               <?php foreach($fileinfo as $value): ?>
                                <tr>
                                    <td><?php echo $value->id ?></td>
                                    
                                    <td><?php echo $value->pas_nama ?></td>
                                    <td><?php echo $value->pas_nik ?></td>
                                    <td><?php echo $value->pas_stat ?></td>
                                    <td><?php echo $value->pas_tmpt ?></td>
                                    <td><?php echo $value->pas_tgl ?></td>
                                    <td><?php echo $value->pas_pek ?></td>
                                    <td><?php echo $value->pas_instansi ?></td>
                                    <td><a href="<?php echo base_url(); ?>assets/images/users/<?php echo $value->file_url ?>" target="_blank"><img src="<?php echo base_url(); ?>assets/images/docs.png" width="30px"></a>
                                    <?php if($this->session->userdata('user_type')=='EMPLOYEE'){ ?>
                                                    <?php } else { ?>
                                    <a href="#" title="Edit" class="filepddkn" data-id="<?php echo $value->id ?>">Ubah Berkas</i></a>
                                    </td>
                                    <td>
                                         
                                        <a href="#" title="Edit" class="btn btn-sm btn-info waves-effect waves-light experience" data-id="<?php echo $value->id ?>"><i class="fa fa-pencil-square-o"></i></a>
                                        <a onclick="return confirm('Apa anda yakin akan menghapus data?')"  href="<?php echo base_url();?>employee/suamiistri_delete/<?php echo $value->id;?>" title="Delete" class="btn btn-sm btn-info waves-effect waves-light"><i class="fa fa-trash-o"></i></a>
                                    <?php }?>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>                                    
                               

                                    
                                </div>

<div class="" id="anak2" role="tabpanel">
                                    <div class="card-body">
                    <h2><div class="text-black" style="">Data Orang Tua</h2>
                    <div class="table-responsive ">
                        <table id="example213" class="table table-hover table-striped" cellspacing="0" width="100%">
                            <thead>
                                <tr>
                                    <th>ID </th>
                                    <th>Nama Ortu</th>
                                    <th>NIK</th>
                                    <th>Status</th>
                                    <th>Tempat Lahir</th>
                                    <th>Pekerjaan</th>
                                    <th>File</th>
                                    
                                </tr>
                            </thead>
                            <tfoot>
                                <tr>
                                    <th>ID </th>
                                    <th>Nama Ortu</th>
                                    <th>NIK</th>
                                    <th>Status</th>
                                    <th>Tempat Lahir</th>
                                    <th>Pekerjaan</th>
                                    <th>File</th>
                                    
                                </tr>
                            </tfoot>
                            <tbody>
                               <?php foreach($anak as $value): ?>
                                <tr>
                                    <td><?php echo $value->id ?></td>
                                    <td><?php echo $value->an_nama ?></td>
                                    <td><?php echo $value->an_nik ?></td>
                                    <td><?php echo $value->an_stat ?></td>
                                    <td><?php echo $value->an_tlahir ?></td>
                                    <td><?php echo $value->an_pek ?></td>
                                    <td><a href="<?php echo base_url(); ?>assets/images/users/<?php echo $value->file_url ?>" target="_blank"><img src="<?php echo base_url(); ?>assets/images/docs.png" width="30px"></a>
                                    <?php if($this->session->userdata('user_type')=='EMPLOYEE'){ ?>
                                                    <?php } else { ?>
                                    <a href="#" title="Edit" class="btn btn-sm btn-info waves-effect waves-light filepddkn" data-id="<?php echo $value->id ?>">Ubah Berkas</i></a>
                                    </td>
                                    <td>
                                             
                                    <a href="#" title="Edit" class="btn btn-sm btn-info waves-effect waves-light education" data-id="<?php echo $value->id ?>"><i class="fa fa-pencil-square-o"></i></a>
                                        
                                        <a onclick="return confirm('Apa anda yakin akan menghapus data?')"  href="<?php echo base_url();?>employee/anak_delete/<?php echo $value->id;?>" title="Delete" class="btn btn-sm btn-info waves-effect waves-light"><i class="fa fa-trash-o"></i></a>
                                    <?php }?>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>      
                                    
                                </div>


<div class="" id="pendidikan2" role="tabpanel">
                                    <div class="card-body">
                    <h2><div class="text-black" style="">Riwayat Pendidikan</h2>
                    <div class="table-responsive ">
                        <table id="example213" class="table table-hover table-striped" cellspacing="0" width="100%">
                            <thead>
                                <tr>
                                    <th>ID </th>
                                    <th>Jenjang</th>
                                    <th>Nama Institusi</th>
                                    <th>Tahun Masuk</th>
                                    <th>Tahun Lulus</th>
                                    <th>Ijazah</th>
                                    
                                </tr>
                            </thead>
                            <tfoot>
                                <tr>
                                    <th>ID </th>
                                    <th>Jenjang</th>
                                    <th>Nama Institusi</th>
                                    <th>Tahun Masuk</th>
                                    <th>Tahun Lulus</th>
                                    <th>Ijazah</th>
                                    
                                </tr>
                            </tfoot>
                            <tbody>
                               <?php foreach($pendidikan as $value): ?>
                                <tr>
                                    <td><?php echo $value->id ?></td>
                                    <td><?php echo $value->jenjang ?></td>
                                    <td><?php echo $value->nama ?></td>
                                    <td><?php echo $value->thn_masuk ?></td>
                                    <td><?php echo $value->thn_lulus ?></td>
                                    <td>

                                        <a href="<?php echo base_url(); ?>assets/images/users/<?php echo $value->file_url ?>" target="_blank"><img src="<?php echo base_url(); ?>assets/images/docs.png" width="30px"></a>
                                    <?php if($this->session->userdata('user_type')=='EMPLOYEE'){ ?>
                                                    <?php } else { ?>
                                    <a href="#" title="Edit" class="btn btn-sm btn-info waves-effect waves-light filepddkn" data-id="<?php echo $value->id ?>">Ubah Berkas</i></a>
                                    </td>
                                    <td>
                                        
                                    <a href="#" title="Edit" class="btn btn-sm btn-info waves-effect waves-light education2" data-id="<?php echo $value->id ?>"><i class="fa fa-pencil-square-o"></i></a>
                                        
                                        <a onclick="return confirm('Apa anda yakin akan menghapus data?')"  href="<?php echo base_url();?>employee/pddkn_delete/<?php echo $value->id;?>" title="Delete" class="btn btn-sm btn-info waves-effect waves-light"><i class="fa fa-trash-o"></i></a>
                                    <?php }?>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>                                    
                               

                                    
                                </div>




<?php }?>
                                    
                                        </div>
                                    </div>
                                </div>                                
                            </div>
                        </div>
                    </div>
                    <!-- Column -->
                </div>
          <script type="text/javascript">
          $('.total').on('input',function() {
            var amount = parseInt($('.total').val());
            $('.basics').val((amount * .50 ? amount * .50 : 0).toFixed(2));

            $('.houserent').val((amount * .40 ? amount * .40 : 0).toFixed(2));
            $('.medical').val((amount * .05 ? amount * .05 : 0).toFixed(2));
            $('.conveyance').val((amount * .05 ? amount * .05 : 0).toFixed(2));
          });
          </script>
<?php $this->load->view('backend/em_modal'); ?>                
<script type="text/javascript">
                                        $(document).ready(function () {
                                            $(".education2").click(function (e) {
                                                e.preventDefault(e);
                                                // Get the record's ID via attribute  
                                                var iid = $(this).attr('data-id');
                                                $('#experience3modal').trigger("reset");
                                                $('#Exp3Modal').modal('show');
                                                $.ajax({
                                                    url: 'pddknbyib?id=' + iid,
                                                    method: 'GET',
                                                    data: '',
                                                    dataType: 'json',
                                                }).done(function (response) {
                                                    console.log(response);
                                                    // Populate the form fields with the data returned from server
                                                    $('#experience3modal').find('[name="id"]').val(response.pddknvalue.id).end();
                                                    $('#experience3modal').find('[name="nama"]').val(response.pddknvalue.nama).end();
                                                    $('#experience3modal').find('[name="jenjang"]').val(response.pddknvalue.jenjang).end();
                                                    $('#experience3modal').find('[name="thn_masuk"]').val(response.pddknvalue.thn_masuk).end();
                                                    $('#experience3modal').find('[name="thn_lulus"]').val(response.pddknvalue.thn_lulus).end();
                                                    $('#experience3modal').find('[name="approval"]').val(response.pddknvalue.approval).end();
                                                    $('#experience3modal').find('[name="k_nip_baru"]').val(response.pddknvalue.k_nip_baru).end();
                                                });
                                            });
                                        });
</script>               

<script type="text/javascript">
                                        $(document).ready(function () {
                                            $(".education").click(function (e) {
                                                e.preventDefault(e);
                                                // Get the record's ID via attribute  
                                                var iid = $(this).attr('data-id');
                                                $('#educationmodal').trigger("reset");
                                                $('#EduModal').modal('show');
                                                $.ajax({
                                                    url: 'anakbyib?id=' + iid,
                                                    method: 'GET',
                                                    data: '',
                                                    dataType: 'json',
                                                }).done(function (response) {
                                                    console.log(response);
                                                    // Populate the form fields with the data returned from server
                                                    $('#educationmodal').find('[name="id"]').val(response.anakvalue.id).end();
                                                    $('#educationmodal').find('[name="nama"]').val(response.anakvalue.an_nama).end();
                                                    $('#educationmodal').find('[name="nik"]').val(response.anakvalue.an_nik).end();
                                                    $('#educationmodal').find('[name="tlahir"]').val(response.anakvalue.an_tlahir).end();
                                                    $('#educationmodal').find('[name="pek"]').val(response.anakvalue.an_pek).end();
                                                    $('#educationmodal').find('[name="stat"]').val(response.anakvalue.an_stat).end();
                                                    $('#educationmodal').find('[name="approval"]').val(response.anakvalue.approval).end();
                                                    $('#educationmodal').find('[name="k_nip_baru"]').val(response.anakvalue.k_nip_baru).end();
                                                });
                                            });
                                        });
</script>      


<script type="text/javascript">
                                        $(document).ready(function () {
                                            $(".experience").click(function (e) {
                                                e.preventDefault(e);
                                                // Get the record's ID via attribute  
                                                var iid = $(this).attr('data-id');
                                                $('#experiencemodal').trigger("reset");
                                                $('#ExpModal').modal('show');
                                                $.ajax({
                                                    url: 'experiencebyib?id=' + iid,
                                                    method: 'GET',
                                                    data: '',
                                                    dataType: 'json',
                                                }).done(function (response) {
                                                    console.log(response);
                                                    // Populate the form fields with the data returned from server
													$('#experiencemodal').find('[name="id"]').val(response.expvalue.id).end();
                                                    $('#experiencemodal').find('[name="pas_nik"]').val(response.expvalue.pas_nik).end();
                                                    $('#experiencemodal').find('[name="pas_nama"]').val(response.expvalue.pas_nama).end();
                                                    $('#experiencemodal').find('[name="pas_stat"]').val(response.expvalue.pas_stat).end();
                                                    $('#experiencemodal').find('[name="pas_tmpt"]').val(response.expvalue.pas_tmpt).end();
                                                    $('#experiencemodal').find('[name="pas_tmpt"]').val(response.expvalue.pas_tmpt).end();
                                                    $('#experiencemodal').find('[name="pas_tgl"]').val(response.expvalue.pas_tgl).end();
                                                    $('#experiencemodal').find('[name="pas_pek"]').val(response.expvalue.pas_pek).end();
                                                    $('#experiencemodal').find('[name="pas_instansi"]').val(response.expvalue.pas_instansi).end();
                                                    $('#experiencemodal').find('[name="approval"]').val(response.expvalue.approval).end();
                                                    $('#experiencemodal').find('[name="k_nip_baru"]').val(response.expvalue.k_nip_baru).end();
												});
                                            });
                                        });
</script>               
<script type="text/javascript">
                                        $(document).ready(function () {
                                            $(".experience2").click(function (e) {
                                                e.preventDefault(e);
                                                // Get the record's ID via attribute  
                                                var iid = $(this).attr('data-id');
                                                $('#experienc2modal').trigger("reset");
                                                $('#Exp2Modal').modal('show');
                                                $.ajax({
                                                    url: 'nikahbyib?id=' + iid,
                                                    method: 'GET',
                                                    data: '',
                                                    dataType: 'json',
                                                }).done(function (response) {
                                                    console.log(response);
                                                    // Populate the form fields with the data returned from server
                                                    $('#experience2modal').find('[name="mrn_id"]').val(response.nikahvalue.mrn_id).end();
                                                    $('#experience2modal').find('[name="mrn_no_surat"]').val(response.nikahvalue.mrn_no_surat).end();
                                                    $('#experience2modal').find('[name="mrn_status"]').val(response.nikahvalue.mrn_status).end();
                                                    $('#experience2modal').find('[name="mrn_tgl_nikah"]').val(response.nikahvalue.mrn_tgl_nikah).end();
                                                    $('#experience2modal').find('[name="file_url"]').val(response.nikahvalue.file_url).end();
                                                    $('#experience2modal').find('[name="approval"]').val(response.nikahvalue.approval).end();
                                                    $('#experience2modal').find('[name="k_nip_baru"]').val(response.nikahvalue.k_nip_baru).end();
                                                });
                                            });
                                        });
</script>               
<script type="text/javascript">
                                        $(document).ready(function () {
                                            $(".experience21").click(function (e) {
                                                e.preventDefault(e);
                                                // Get the record's ID via attribute  
                                                var iid = $(this).attr('data-id');
                                                $('#experienc21modal').trigger("reset");
                                                $('#Exp21Modal').modal('show');
                                                $.ajax({
                                                    url: 'nikahbyib?id=' + iid,
                                                    method: 'GET',
                                                    data: '',
                                                    dataType: 'json',
                                                }).done(function (response) {
                                                    console.log(response);
                                                    // Populate the form fields with the data returned from server
                                                    $('#experience21modal').find('[name="mrn_id"]').val(response.nikahvalue.mrn_id).end();
                                                    $('#experience21modal').find('[name="file_url"]').val(response.nikahvalue.file_url).end();
                                                    $('#experience21modal').find('[name="k_nip_baru"]').val(response.nikahvalue.k_nip_baru).end();
                                                });
                                            });
                                        });
</script>               
<script type="text/javascript">
                                        $(document).ready(function () {
                                            $(".experience23").click(function (e) {
                                                e.preventDefault(e);
                                                // Get the record's ID via attribute  
                                                var iid = $(this).attr('data-id');
                                                $('#experienc23modal').trigger("reset");
                                                $('#Exp23Modal').modal('show');
                                                $.ajax({
                                                    url: 'anakbyib?id=' + iid,
                                                    method: 'GET',
                                                    data: '',
                                                    dataType: 'json',
                                                }).done(function (response) {
                                                    console.log(response);
                                                    // Populate the form fields with the data returned from server
                                                    $('#experience23modal').find('[name="id"]').val(response.anakvalue.id).end();
                                                    $('#experience23modal').find('[name="file_url"]').val(response.anakvalue.file_url).end();
                                                    $('#experience23modal').find('[name="k_nip_baru"]').val(response.anakvalue.k_nip_baru).end();
                                                });
                                            });
                                        });
</script>               
<script type="text/javascript">
                                        $(document).ready(function () {
                                            $(".experience24").click(function (e) {
                                                e.preventDefault(e);
                                                // Get the record's ID via attribute  
                                                var iid = $(this).attr('data-id');
                                                $('#experienc24modal').trigger("reset");
                                                $('#Exp24Modal').modal('show');
                                                $.ajax({
                                                    url: 'pddknbyib?id=' + iid,
                                                    method: 'GET',
                                                    data: '',
                                                    dataType: 'json',
                                                }).done(function (response) {
                                                    console.log(response);
                                                    // Populate the form fields with the data returned from server
                                                    $('#experience24modal').find('[name="id"]').val(response.pddknvalue.id).end();
                                                    $('#experience24modal').find('[name="file_url"]').val(response.pddknvalue.file_url).end();
                                                    $('#experience24modal').find('[name="k_nip_baru"]').val(response.pddknvalue.k_nip_baru).end();
                                                });
                                            });
                                        });
</script>               
<script type="text/javascript">
                                        $(document).ready(function () {
                                            $(".experience22").click(function (e) {
                                                e.preventDefault(e);
                                                // Get the record's ID via attribute  
                                                var iid = $(this).attr('data-id');
                                                $('#experienc22modal').trigger("reset");
                                                $('#Exp22Modal').modal('show');
                                                $.ajax({
                                                    url: 'experiencebyib?id=' + iid,
                                                    method: 'GET',
                                                    data: '',
                                                    dataType: 'json',
                                                }).done(function (response) {
                                                    console.log(response);
                                                    // Populate the form fields with the data returned from server
                                                    $('#experience22modal').find('[name="id"]').val(response.expvalue.id).end();
                                                    $('#experience21modal').find('[name="file_url"]').val(response.expvalue.file_url).end();
                                                    $('#experience21modal').find('[name="k_nip_baru"]').val(response.expvalue.k_nip_baru).end();
                                                });
                                            });
                                        });
</script>               


<script type="text/javascript">
                                        $(document).ready(function () {
                                            $(".deletexp").click(function (e) {
                                                e.preventDefault(e);
                                                // Get the record's ID via attribute  
                                                var iid = $(this).attr('data-id');
                                                $.ajax({
                                                    url: 'EXPvalueDelet?id=' + iid,
                                                    method: 'GET',
                                                    data: 'data',
                                                }).done(function (response) {
                                                    console.log(response);
                                                    $(".message").fadeIn('fast').delay(3000).fadeOut('fast').html(response);
                                                    window.setTimeout(function(){location.reload()},2000)
                                                    // Populate the form fields with the data returned from server
												});
                                            });
                                        });
</script>                 
<script type="text/javascript">
                                        $(document).ready(function () {
                                            $(".edudelet").click(function (e) {
                                                e.preventDefault(e);
                                                // Get the record's ID via attribute  
                                                var iid = $(this).attr('data-id');
                                                $.ajax({
                                                    url: 'EduvalueDelet?id=' + iid,
                                                    method: 'GET',
                                                    data: 'data',
                                                }).done(function (response) {
                                                    console.log(response);
                                                    $(".message").fadeIn('fast').delay(3000).fadeOut('fast').html(response);
                                                    window.setTimeout(function(){location.reload()},2000)
                                                    // Populate the form fields with the data returned from server
												});
                                            });
                                        });
</script>                
  <script>
   $(document).ready(function() {
  
     $("#test").hide();
     $("#tombol_biodata").click(function() {
       $("#nikah2").show(1000);
       $("#suamiistri2").show(1000);
       $("#anak2").show(1000);
       $("#pendidikan2").show(1000);
     })
  
     $("#tombol_change").click(function() {
       
       $("#nikah2").hide(1000);
       $("#suamiistri2").hide(1000);
       $("#anak2").hide(1000);
       $("#pendidikan2").hide(1000);
     })

     $("#tombol_change2").click(function() {
       
       $("#nikah2").hide(1000);
       $("#suamiistri2").hide(1000);
       $("#anak2").hide(1000);
       $("#pendidikan2").hide(1000);
     })

     $("#tombol_change3").click(function() {
       
       $("#nikah2").hide(1000);
       $("#suamiistri2").hide(1000);
       $("#anak2").hide(1000);
       $("#pendidikan2").hide(1000);
     })

     $("#tombol_change4").click(function() {
       
       $("#nikah2").hide(1000);
       $("#suamiistri2").hide(1000);
       $("#anak2").hide(1000);
       $("#pendidikan2").hide(1000);
     })

     $("#tombol_change5").click(function() {
       
       $("#nikah2").hide(1000);
       $("#suamiistri2").hide(1000);
       $("#anak2").hide(1000);
       $("#pendidikan2").hide(1000);
     })
  
   });
   </script>
   <script>
    <?php if(isset($areavalue)) :?>
    var selectValues = { 
        <?php foreach($areavalue as $value): ?>
            "<?php echo $value->area_id ?>" : ["<?php echo $value->area_nama ?>",<?php echo $value->area_sat_kode ?>],
        <?php endforeach; ?>
        };
    $(document).ready(function() {
        $('#sat').change(function() {
            $('#area option').remove();
            var cur_sat = $(this).val();
            $.each(selectValues, function(key, value) {   
                if(value[1] == cur_sat)
                $('#area')
                    .append($("<option></option>")
                                .attr("value",value[0])
                                .text(value[0])); 
            });
        });
    });
    <?php endif?>
    </script>
<?php $this->load->view('backend/footer'); ?>
