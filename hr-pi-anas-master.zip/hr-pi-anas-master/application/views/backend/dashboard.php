    <?php $this->load->view('backend/header'); ?>
    <?php $this->load->view('backend/sidebar'); ?>
        <?php 
                        $id = $this->session->userdata('user_login_id');
                        $basicinfo = $this->employee_model->GetBasics($id); 
                        ?>       
          <div class="page-wrapper">
                <br><br>
                <div class="message"></div>
                <div class="row page-titles">
                    
                    <div class="col-md-5 align-self-center">
                        <h3 class="text-themecolor"><i class="fa fa-braille" style="color:#1976d2"></i>&nbsp Dashboard</h3>
                    </div>
                    <div class="col-md-7 align-self-center">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="javascript:void(0)">Beranda</a></li>
                            
                        </ol>
                    </div>
                </div>
                <!-- Container fluid  -->
                <!-- ============================================================== -->
                <div class="container-fluid">
                    <!-- ============================================================== -->
                    <!-- Row -->
                    
                    <div class="row">
                        <!-- Column -->
                        <?php if($this->session->userdata('user_type')=='EMPLOYEE'){ ?>
                                                    <?php } else { ?>
                        <div class="col-lg-3 col-md-6">
                            <div class="card">
                                <div class="card-body">
                                    <div class="d-flex flex-row">
                                        <div class="round align-self-center round-success"><i class="ti-wallet"></i></div>
                                        <div class="m-l-10 align-self-center">
                                            <h3 class="m-b-0">

                                        <?php 
                                            
                                            $this->db->from("master_kar");
                                            $this->db->where('k_stakepeg', 'Aktif');
                                            echo $this->db->count_all_results();
                                        ?>  Pegawai</h3>
                                            <a href="<?php echo base_url(); ?>employee/Employees" class="text-muted m-b-0">Lihat Master Pegawai</a></div>
                                    </div>
                                </div>
                            </div>
                        </div><?php } ?>
                        <!-- <div class="col-lg-3 col-md-6">
                            <div class="card">
                               <div id="tombol_show" class="card-body">
                                    <div class="d-flex flex-row">
                                        <div class="round align-self-center round-success"><i class="ti-wallet"></i></div>
                                        <div class="m-l-10 align-self-center">
                                            <h3 class="m-b-0">
                                          Tugas</h3>
                                            <div id="tombol_show"><a href="#" class="text-muted m-b-0">Lihat Tugas</a></div></div>
                                    </div>
                                </div>
                            </div>
                        </div>-->
                        <?php if($this->session->userdata('user_type')!='EMPLOYEE'){ ?>
                                                    <?php } else { ?>
                        <div class="col-lg-3 col-md-6">
                            <div class="card">
                               <div id="tombol_show" class="card-body">
                                    <div class="d-flex flex-row">
                                        <div class="round align-self-center round-success"><i class="ti-wallet"></i></div>
                                        <div class="m-l-10 align-self-center">
                                            <h3 class="m-b-0">
                                          Biodata</h3>
                                            <a href="<?php echo base_url(); ?>employee/view?I=<?php echo base64_encode($basicinfo->k_nip_baru); ?>" class="text-muted m-b-0">Kelola Biodata</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php }?>
                        <?php if($this->session->userdata('user_type')=='EMPLOYEE'){ ?>
                                                    <?php } else { ?>
                        <div class="col-lg-3 col-md-6">
                            <div class="card">
                                <div class="card-body">
                                    <div class="d-flex flex-row">
                                        <div class="round align-self-center round-danger"><i class="ti-calendar"></i></div>
                                        <div class="m-l-10 align-self-center">
                                            <h3 class="m-b-0"> 
                                             <?php 
                                                    $this->db->where('k_stakepeg','pensiun');
                                                    $this->db->from("master_kar");
                                                    echo $this->db->count_all_results();
                                                ?> Pensiun
                                            </h3>
                                            <?php if($this->session->userdata('user_type')=='EMPLOYEE'){ ?>
                                                    <?php } else { ?>
                                            <a href="<?php echo base_url(); ?>Employee/pensiun" class="text-muted m-b-0">Lihat master pensiun</a><?php }?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php }?>
                        <!-- Column -->
                        <!-- Column -->
                        
                        <!-- Column -->
                    </div>

                    
                <div class="container-fluid">
                    <?php $notice = $this->notice_model->GetNoticelimit(); 
                    $running = $this->dashboard_model->GetRunningProject(); 
                    $userid = $this->session->userdata('user_login_id');
                    $todolist = $this->dashboard_model->GettodoInfo($userid);                 
                    $holiday = $this->dashboard_model->GetHolidayInfo();                 
                    ?>
                    <!-- Row -->
                    <center>
                    <div id="test" class="col-lg-4">
                        <div class="card">
                            <div class="card-body">
                            <!----
                                <center><h4 class="card-title">Daftar Tugas</h4>
                                <h6 class="card-subtitle">Daftar Tugas yang anda kerjakan</h6></center>
                                <div id="" class="to-do-widget m-t-20" style="height:450px; width:300px;overflow-y:scroll">
                                            <ul class="list-task todo-list list-group m-b-0" data-role="tasklist">
                                               <?php foreach($todolist as $value): ?>
                                                <li class="list-group-item" data-role="task">
                                                   <?php if($value->value == '1'){ ?>
                                                    <div class="checkbox checkbox-info">
                                                        <input class="to-do" data-id="<?php echo $value->id?>" data-value="0" type="checkbox" id="<?php echo $value->id?>" >
                                                        <label for="<?php echo $value->id?>"><span><?php echo $value->to_dodata; ?></span><br><span><i class="text-blue">Due date : <?php echo $value->deadline;?></i> </span></label>
                                                    </div>
                                                    <?php } else { ?>
                                                    <div class="checkbox checkbox-info">
                                                        <input class="to-do" data-id="<?php echo $value->id?>" data-value="1" type="checkbox" id="<?php echo $value->id?>" checked>
                                                        <label for="<?php echo $value->id?>"><span><?php echo $value->to_dodata; ?></span><br><span><i class="text-blue">Due date : <?php echo $value->deadline;?></i> </span></label>
                                                    </div> 
                                                    <?php } ?>                                                   
                                                </li>

                                                <?php endforeach; ?>
                                            </ul>                                    
                                </div>
                                <div class="new-todo">
                                   <form method="post" action="add_todo" enctype="multipart/form-data" id="add_todo" >
                                    <div class="input-group">
                                        <input type="text" name="todo_data" class="form-control" style="border: 1px solid #fff !IMPORTANT;" placeholder="Input tugas baru">
                                        
                                    </div>
                                    <div class="input-group">
                                        
                                        <input type="date" name="dl" id="example-email2" name="example-email" class="form-control" style="border: 1px solid #fff !IMPORTANT;" placeholder="Deadline Tugas" required> 
                                        <span class="input-group-btn">
                                        <input type="hidden" name="userid" value="<?php echo $this->session->userdata('user_login_id'); ?>">
                                        <button type="submit" class="btn btn-success todo-submit"><i class="fa fa-plus"></i></button>
                                        </span> 
                                    </div>
                                    </form>
                                </div>     -->                           
                            </div>
                        </div>
                    </div></center>
                </div>
<?php if($this->session->userdata('user_type')=='EMPLOYEE'){ ?>
                                                    <?php } else { ?>
        <center>
            <h2>GRAFIK JENIS KELAMIN</h2>
        </center>


        <div style="width: 500px;margin: 0px auto;">
            <canvas id="myChart"></canvas>
        </div><br><br>
        
        <center>
            <h2>GRAFIK PENDIDIKAN</h2>
        </center>

        <div style="width: 600px;margin: 0px auto;">
            <canvas id="myChart2"></canvas>
        </div><br><br>
        
        <center>
            <h2>GRAFIK JENIS JABATAN</h2>
        </center>

        <div style="width: 400px; margin: 0px auto;">
            <canvas id="myChart3"></canvas>
        </div><br><br>
<center>
            <h2>GRAFIK PANGKAT GOLONGAN</h2>
        </center>

        <div style="width: 800px;margin: 0px auto;">
            <canvas id="myChart4"></canvas>
        </div><?php }?>

        <br/>
        <br/>
        <?php 
    $koneksi = mysqli_connect("localhost","root","","genhr");
    ?>
        <script>
   $(document).ready(function() {
  
     $("#test").hide();
     $("#tombol_hide").click(function() {
       $("#test").hide(1000);
     })
  
     $("#tombol_show").click(function() {
       $("#test").show(1000);
     })
  
   });
   </script>
   <style>
   #box {
     width: 300px;
     height: 80px;
     background-color: pink;
     border: 2px solid black;
   }
   </style>

        <script>
            var ctx = document.getElementById("myChart").getContext('2d');
            var myChart = new Chart(ctx, {
                type: 'pie',
                data: {
                    labels: ["Laki-laki", "Perempuan"],
                    datasets: [{
                        label: '',
                        data: [
                        <?php 
                        $jumlah_laki = mysqli_query($koneksi,"select * from master_kar where k_jk='1'");
                        echo mysqli_num_rows($jumlah_laki);
                        ?>, 
                        <?php 
                        $jumlah_perempuan = mysqli_query($koneksi,"select * from master_kar where k_jk='2'");
                        echo mysqli_num_rows($jumlah_perempuan);
                        ?>
                        ],
                        backgroundColor: [
                        'rgba(255, 99, 132, 6.2)',
                        'rgba(54, 162, 235, 6.2)'
                        ],
                        borderColor: [
                        'rgba(255,99,132,1)',
                        'rgba(54, 162, 235, 1)'
                        ],
                        borderWidth: 1
                    }]
                },
                options: {
                    scales: {
                        yAxes: [{
                            ticks: {
                                beginAtZero:true
                            }
                        }]
                    }
                }
            });
        </script>
        <script>
            var ctx = document.getElementById("myChart2").getContext('2d');
            var myChart2 = new Chart(ctx, {
                type: 'bar',
                data: {
                    labels: ["S3", "S2","S1","D1","SMA","SMP","SD","D2","D3","D4"],
                    datasets: [{
                        label: '',

                        data: [
                        <?php 
                        $jumlah_1 = mysqli_query($koneksi,"select * from master_kar where k_pendidikan='1'");
                        echo mysqli_num_rows($jumlah_1);
                        ?>,
                        <?php 
                        $jumlah_2 = mysqli_query($koneksi,"select * from master_kar where k_pendidikan='2'");
                        echo mysqli_num_rows($jumlah_2);
                        ?>, 
                        <?php 
                        $jumlah_3 = mysqli_query($koneksi,"select * from master_kar where k_pendidikan='3'");
                        echo mysqli_num_rows($jumlah_3);
                        ?>,
                        <?php 
                        $jumlah_4 = mysqli_query($koneksi,"select * from master_kar where k_pendidikan='4'");
                        echo mysqli_num_rows($jumlah_4);
                        ?>, 
                        <?php 
                        $jumlah_5 = mysqli_query($koneksi,"select * from master_kar where k_pendidikan='5'");
                        echo mysqli_num_rows($jumlah_5);
                        ?>,
                        <?php 
                        $jumlah_6 = mysqli_query($koneksi,"select * from master_kar where k_pendidikan='6'");
                        echo mysqli_num_rows($jumlah_6);
                        ?>, 
                        <?php 
                        $jumlah_7 = mysqli_query($koneksi,"select * from master_kar where k_pendidikan='7'");
                        echo mysqli_num_rows($jumlah_7);
                        ?>,
                        <?php 
                        $jumlah_8 = mysqli_query($koneksi,"select * from master_kar where k_pendidikan='8'");
                        echo mysqli_num_rows($jumlah_8);
                        ?>, 
                        <?php 
                        $jumlah_9 = mysqli_query($koneksi,"select * from master_kar where k_pendidikan='9'");
                        echo mysqli_num_rows($jumlah_9);
                        ?>, 
                        <?php 
                        $jumlah_10 = mysqli_query($koneksi,"select * from master_kar where k_pendidikan='10'");
                        echo mysqli_num_rows($jumlah_9);
                        ?>, 
                        ],
                        backgroundColor: [
                        'rgba(255, 99, 132, 6.2)',
                        'rgba(54, 162, 235, 6.2)',
                        'rgba(255, 99, 132, 6.2)',
                        'rgba(54, 162, 235, 6.2)',
                        'rgba(255, 99, 132, 6.2)',
                        'rgba(54, 162, 235, 6.2)',
                        'rgba(255, 99, 132, 6.2)',
                        'rgba(54, 162, 235, 6.2)',
                        'rgba(255, 99, 132, 6.2)',
                        
                        ],
                        borderColor: [
                        'rgba(255,99,132,1)',
                        'rgba(54, 162, 235, 1)',
                        'rgba(255,99,132,1)',
                        'rgba(54, 162, 235, 1)',
                        'rgba(255,99,132,1)',
                        'rgba(54, 162, 235, 1)',
                        'rgba(255,99,132,1)',
                        'rgba(54, 162, 235, 1)',
                        'rgba(255,99,132,1)',
                        'rgba(54, 162, 235, 1)'

                        ],
                        borderWidth: 1
                    }]
                },
                options: {
                    scales: {
                        yAxes: [{
                            ticks: {
                                beginAtZero:true
                            }
                        }]
                    }
                }
            });
        </script>
        <script>
            var ctx = document.getElementById("myChart3").getContext('2d');
            var myChart3 = new Chart(ctx, {
                type: 'bar',
                data: {
                    labels: ["Struktural", "Fungsional", "Pelaksana"],
                    datasets: [{
                        label: '',
                        data: [
                        <?php 
                        $jumlah_s = mysqli_query($koneksi,"select * from master_kar where k_jenis_jabatan='1'");
                        echo mysqli_num_rows($jumlah_s);
                        ?>, 
                        <?php 
                        $jumlah_f = mysqli_query($koneksi,"select * from master_kar where k_jenis_jabatan='2'");
                        echo mysqli_num_rows($jumlah_f);
                        ?>,
                        <?php 
                        $jumlah_p = mysqli_query($koneksi,"select * from master_kar where k_jenis_jabatan='3'");
                        echo mysqli_num_rows($jumlah_p);
                        ?>
                        ],
                        backgroundColor: [
                        'rgba(255, 99, 132, 6.2)',
                        'rgba(54, 162, 235, 6.2)',
                        'rgba(255, 99, 132, 6.2)'
                        ],
                        borderColor: [
                        'rgba(255,99,132,1)',
                        'rgba(54, 162, 235, 1)'
                        ],
                        borderWidth: 1
                    }]
                },
                options: {
                    scales: {
                        yAxes: [{
                            ticks: {
                                beginAtZero:true
                            }
                        }]
                    }
                }
            });
        </script>

<script>
            var ctx = document.getElementById("myChart4").getContext('2d');
            var myChart4 = new Chart(ctx, {
                type: 'bar',        
                data: {
                    labels: ["IV/e", "IV/d", "IV/c", 'IV/b', 'IV/a', 'III/d','III/c','III/b','III/a','II/d','II/c','II/b','II/a','I/d','I/c','I/b','I/a'],
                    datasets: [{
                        label: '',
                        data: [
                        <?php 
                        $jumlah_1 = mysqli_query($koneksi,"select * from master_kar where k_golongan='1'");
                        echo mysqli_num_rows($jumlah_1);
                        ?>, 
                        <?php 
                        $jumlah_2 = mysqli_query($koneksi,"select * from master_kar where k_golongan='2'");
                        echo mysqli_num_rows($jumlah_2);
                        ?>, 
                        <?php 
                        $jumlah_3 = mysqli_query($koneksi,"select * from master_kar where k_golongan='3'");
                        echo mysqli_num_rows($jumlah_3);
                        ?>, 
                        <?php 
                        $jumlah_4 = mysqli_query($koneksi,"select * from master_kar where k_golongan='4'");
                        echo mysqli_num_rows($jumlah_4);
                        ?>, 
                        <?php 
                        $jumlah_5 = mysqli_query($koneksi,"select * from master_kar where k_golongan='5'");
                        echo mysqli_num_rows($jumlah_5);
                        ?>, 
                        <?php 
                        $jumlah_6 = mysqli_query($koneksi,"select * from master_kar where k_golongan='6'");
                        echo mysqli_num_rows($jumlah_6);
                        ?>, 
                        <?php 
                        $jumlah_7 = mysqli_query($koneksi,"select * from master_kar where k_golongan='7'");
                        echo mysqli_num_rows($jumlah_7);
                        ?>, 
                        <?php 
                        $jumlah_8 = mysqli_query($koneksi,"select * from master_kar where k_golongan='8'");
                        echo mysqli_num_rows($jumlah_8);
                        ?>, 
                        <?php 
                        $jumlah_9 = mysqli_query($koneksi,"select * from master_kar where k_golongan='9'");
                        echo mysqli_num_rows($jumlah_9);
                        ?>, 
                        <?php 
                        $jumlah_10 = mysqli_query($koneksi,"select * from master_kar where k_golongan='10'");
                        echo mysqli_num_rows($jumlah_10);
                        ?>, 
                        <?php 
                        $jumlah_11 = mysqli_query($koneksi,"select * from master_kar where k_golongan='11'");
                        echo mysqli_num_rows($jumlah_11);
                        ?>, 
                        <?php 
                        $jumlah_12 = mysqli_query($koneksi,"select * from master_kar where k_golongan='12'");
                        echo mysqli_num_rows($jumlah_12);
                        ?>, 
                        <?php 
                        $jumlah_13 = mysqli_query($koneksi,"select * from master_kar where k_golongan='13'");
                        echo mysqli_num_rows($jumlah_13);
                        ?>, 
                        <?php 
                        $jumlah_14 = mysqli_query($koneksi,"select * from master_kar where k_golongan='14'");
                        echo mysqli_num_rows($jumlah_14);
                        ?>, 
                        <?php 
                        $jumlah_15 = mysqli_query($koneksi,"select * from master_kar where k_golongan='15'");
                        echo mysqli_num_rows($jumlah_15);
                        ?>, 
                        <?php 
                        $jumlah_16 = mysqli_query($koneksi,"select * from master_kar where k_golongan='16'");
                        echo mysqli_num_rows($jumlah_16);
                        ?>, 
                        <?php 
                        $jumlah_17 = mysqli_query($koneksi,"select * from master_kar where k_golongan='17'");
                        echo mysqli_num_rows($jumlah_17);
                        ?>, 

                        ],
                        backgroundColor: [
                        'rgba(255, 99, 132, 6.2)',
                        'rgba(54, 162, 235, 6.2)',
                        'rgba(255, 99, 132, 6.2)',
                        'rgba(54, 162, 235, 6.2)',

                        'rgba(255, 99, 132, 6.2)',
                        'rgba(54, 162, 235, 6.2)',
                        'rgba(255, 99, 132, 6.2)',
                        'rgba(54, 162, 235, 6.2)',
                        
                        'rgba(255, 99, 132, 6.2)',
                        'rgba(54, 162, 235, 6.2)',
                        'rgba(255, 99, 132, 6.2)',
                        'rgba(54, 162, 235, 6.2)',
                        
                        'rgba(255, 99, 132, 6.2)',
                        'rgba(54, 162, 235, 6.2)',
                        'rgba(255, 99, 132, 6.2)',
                        'rgba(54, 162, 235, 6.2)',
                        ],
                        borderColor: [
                        'rgba(255,99,132,1)',
                        'rgba(54, 162, 235, 1)'
                        ],
                        borderWidth: 1
                    }]
                },
                options: {
                    scales: {
                        yAxes: [{
                            ticks: {
                                beginAtZero:true
                            }
                        }]
                    }
                }
            });
        </script>

    <script type="text/javascript" src="<?php echo base_url(); ?>assets/plugins/Chart.js/chart.js"></script>                
    <script>
      $(".to-do").on("click", function(){
          //console.log($(this).attr('data-value'));
          $.ajax({
              url: "Update_Todo",
              type:"POST",
              data:
              {
              'toid': $(this).attr('data-id'),         
              'tovalue': $(this).attr('data-value'),
              },
              success: function(response) {
                  location.reload();
              },
              error: function(response) {
                console.error();
              }
          });
      });			
    </script>                                               
    <?php $this->load->view('backend/footer'); ?>