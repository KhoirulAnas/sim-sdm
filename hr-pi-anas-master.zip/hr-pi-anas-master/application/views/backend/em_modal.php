<?php $kotavalue = $this->employee_model->getkota(); ?> 
<?php $pendidikanvalue = $this->employee_model->getpddkn(); ?>                        
<?php $getpddknvalue = $this->employee_model->getpddknv(); ?>
<?php $nikahedit = $this->employee_model->nikahedit(); ?>
<?php $suamiistri = $this->employee_model->suamiistri(); ?>
<?php $ortu = $this->employee_model->ortu(); ?>

                        <div class="modal fade" style="margin-top: 50px;" id="EduModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel1">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content ">
                                    <div class="modal-header">
                                        <h4 class="modal-title" id="exampleModalLabel1">EDIT DATA ORANG TUA</h4>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                    </div>
                                    <form method="post" action="Edit_Ortu" id="educationmodal" enctype="multipart/form-data">
                                    <div class="modal-body">
			                                    <div class="form-group">
			                                        <label>Nama Orang Tua</label>
			                                        <input type="text" name="nama" class="form-control form-control-line" placeholder=" " minlength="2"> 
			                                    </div>
			                                    <div class="form-group">
			                                        <label>NIK</label>
			                                        <input type="text" name="nik" class="form-control form-control-line" placeholder="  " minlength="1"> 
			                                    </div>
                                                <div class="form-group">
                                                    <label>Status</label>
                                                    <input type="text" name="stat" class="form-control form-control-line" placeholder="  " minlength="1"> 
                                                </div>
                                                                <div class="form-group">
                                        
                                        <label>Tempat Lahir </label>
                                        <select name="tlahir" value=""   class="form-control custom-select" required>
                                            <option><?php echo $basics->k_tlahir; ?></option>
                                            <?Php foreach($kotavalue as $value): ?>
                                            <option value="<?php echo $value->lokasi_nama ?>"><?php echo $value->lokasi_nama ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                                <div class="form-group">
                                                    <label>Pekerjaan</label>
                                                    <input type="text" name="pek" class="form-control form-control-line" placeholder="  " minlength="1"> 
                                                </div>
			                                    <div class="form-group">
        <label>Status Persetujuan</label>
        <select name="approval" <?php if($this->session->userdata('user_type')=='EMPLOYEE'){ ?> readonly <?php } ?> class="form-control" required>
                                            <?Php foreach($ortu as $value): ?><?php endforeach; ?>
                                            <option value="<?php echo $value->approval ?>"><?php echo $value->approval ?></option>
                                            <?php if($this->session->userdata('user_type')!='EMPLOYEE'){ ?> 
                                            <option value="belum disetujui">Belum disetujui</option>
                                            <option value="telah disetujui">Telah disetujui</option>
                                            <option value="tidak disetujui">Tidak disetujui</option>
                                            <?php } ?>
                                            
                                        </select>
     </div>
                                    </div>
                                    <div class="modal-footer">
                                        <input type="hidden" name="k_nip_baru" value=""> 
                                        <input type="hidden" name="id" value=""> 
                                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                        <button type="submit" class="btn btn-primary">Submit</button>
                                    </div>
                                    </form>
                                </div>
                            </div>
                        </div>      

                        <!-- sample modal content -->
                        <div class="modal fade" style="margin-top: 50px;" id="Exp3Modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel1">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content ">
                                    <div class="modal-header">
                                        <h4 class="modal-title" id="exampleModalLabel1">EDIT </h4>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                    </div>
                                    <form method="post" action="Edit_Pddkn" id="experience3modal" enctype="multipart/form-data">
                                    <div class="modal-body">
                                                <div class="form-group">
                                                    <label>Jenjang</label>
                                                    <select name="jenjang" value=""  class="form-control custom-select" required>
                                            <option>pilih</option>
                                            <?Php foreach($pendidikanvalue as $value): ?>
                                            <option value="<?php echo $value->pend_jenjang ?>"><?php echo $value->pend_jenjang ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                                </div>
                                                <div class="form-group">
                                                    <label>nama</label>
                                                    <input type="text" name="nama" class="form-control form-control-line" placeholder="  " minlength="1"> 
                                                </div>
                                                <div class="form-group">
                                                    <label>tahun masuk</label>
                                                    <input type="date" name="thn_masuk" class="form-control form-control-line" placeholder="  " minlength="1"> 
                                                </div>
                                                <div class="form-group">
                                                    <label>Tahun Lulus</label>
                                                    <input type="date" name="thn_lulus" class="form-control form-control-line" placeholder="  " minlength="1"> 
                                                </div>
                                                 
                                                <div class="form-group">
        <label>Status Persetujuan</label>
        <select name="approval" <?php if($this->session->userdata('user_type')=='EMPLOYEE'){ ?> readonly <?php } ?> class="form-control" required>
                                            <?Php foreach($getpddknvalue as $value): ?><?php endforeach; ?>
                                            <option value="<?php echo $value->approval ?>"><?php echo $value->approval ?></option>
                                            <?php if($this->session->userdata('user_type')!='EMPLOYEE'){ ?> 
                                            <option value="belum disetujui">Belum disetujui</option>
                                            <option value="telah disetujui">Telah disetujui</option>
                                            <option value="tidak disetujui">Tidak disetujui</option>
                                            <?php } ?>
                                    
                                        </select>
     </div>
                                                
                                    </div>
                                    <div class="modal-footer">
                                        <input type="hidden" name="k_nip_baru" value=""> 
                                        <input type="hidden" name="id" value=""> 
                                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                        <button type="submit" class="btn btn-primary">Submit</button>
                                    </div>
                                    </form>
                                </div>
                            </div>
                        </div>                        
                        <!-- sample modal content -->

                          
                        <!-- sample modal content -->
                        <div class="modal fade" style="margin-top: 50px;" id="ExpModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel1">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content ">
                                    <div class="modal-header">
                                        <h4 class="modal-title" id="exampleModalLabel1">EDIT DATA</h4>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                    </div>
                                    <form method="post" action="Edit_suamiistri" id="experiencemodal" enctype="multipart/form-data">
                                    <div class="modal-body">
			                                    	<div class="form-group">
			                                    	    <label> Nama Pasangan</label>
			                                    	    <input type="text" name="pas_nama" class="form-control form-control-line company_name" placeholder="" minlength="2" required> 
			                                    	</div>
			                                    	<div class="form-group">
			                                    	    <label>NIK</label>
			                                    	    <input type="text" name="pas_nik" class="form-control form-control-line position_name" placeholder="" minlength="3" required> 
			                                    	</div>
			                                    	<div class="form-group">
			                                    	    <label>Status</label>
			                                    	    <input type="text" name="pas_stat" class="form-control form-control-line duty" placeholder=" " minlength="1" required> 
			                                    	</div>
			                                                      <div class="form-group">
                                        <label>Tempat Lahir </label>
                                        <select name="pas_tmpt" value=""   class="form-control custom-select" required>
                                            <option><?php echo $basics->k_tlahir; ?></option>
                                            <?Php foreach($kotavalue as $value): ?>
                                            <option value="<?php echo $value->lokasi_nama ?>"><?php echo $value->lokasi_nama ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                                    <div class="form-group">
                                                        <label>Tanggal Lahir</label>
                                                        <input type="date" name="pas_tgl" class="form-control form-control-line working_period" placeholder="" required> 
                                                    </div>    
                                                    <div class="form-group">
                                                        <label>Pekerjaan</label>
                                                        <input type="text" name="pas_pek" class="form-control form-control-line working_period" placeholder="" required> 
                                                    </div>    
                                                    <div class="form-group">
                                                        <label>Instansi</label>
                                                        <input type="text" name="pas_instansi" class="form-control form-control-line working_period" placeholder="" required> 
                                                    </div>    
                                                                <div class="form-group">
        <label>Status Persetujuan</label>
        <select name="approval" <?php if($this->session->userdata('user_type')=='EMPLOYEE'){ ?> readonly <?php } ?> class="form-control" required>
                                            <?Php foreach($suamiistri as $value): ?><?php endforeach; ?>
                                            <option value="<?php echo $value->approval ?>"><?php echo $value->approval ?></option>
                                            <?php if($this->session->userdata('user_type')!='EMPLOYEE'){ ?> 
                                            <option value="belum disetujui">Belum disetujui</option>
                                            <option value="telah disetujui">Telah disetujui</option>
                                            <option value="tidak disetujui">Tidak disetujui</option>
                                            <?php } ?>
                                            
                                        </select>
     </div>
                                        
                                    </div>
                                    <div class="modal-footer">
                                        <input type="hidden" name="k_nip_baru" value=""> 
                                        <input type="hidden" name="id" value=""> 
                                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                        <button type="submit" class="btn btn-primary">Submit</button>
                                    </div>
                                    </form>
                                </div>
                            </div>
                        </div>

 <!-- sample modal content -->
                        <div class="modal fade" style="margin-top: 50px;" id="Exp2Modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel1">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content ">
                                    <div class="modal-header">
                                        <h4 class="modal-title" id="exampleModalLabel1">EDIT DATA</h4>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                    </div>
                                    <form method="post" action="Edit_nikah" id="experience2modal" enctype="multipart/form-data">
                                    <div class="modal-body">
                                                    <div class="form-group">
                                                        <label> Nomor Surat Nikah</label>
                                                        <input type="text" name="mrn_no_surat" class="form-control form-control-line company_name" placeholder="" minlength="2" required> 
                                                    </div>
                                                    <div class="form-group">
                                                        <label>Status NikahK</label>
                                                        <input type="text" name="mrn_status" class="form-control form-control-line position_name" placeholder="" minlength="3" required> 
                                                    </div>
                                                    <div class="form-group">
                                                        <label>Tanggal Nikah</label>
                                                        <input type="date" name="mrn_tgl_nikah" class="form-control form-control-line working_period" placeholder="" required> 
                                                    </div>             
                                                                <div class="form-group">
        <label>Status Persetujuan</label>
        <select name="approval" <?php if($this->session->userdata('user_type')=='EMPLOYEE'){ ?> readonly <?php } ?> class="form-control" required>
                                            <?Php foreach($nikahedit as $value): ?><?php endforeach; ?>
                                            <option value="<?php echo $value->approval ?>"><?php echo $value->approval ?></option>
                                            <?php if($this->session->userdata('user_type')!='EMPLOYEE'){ ?> 
                                            <option value="belum disetujui">Belum disetujui</option>
                                            <option value="telah disetujui">Telah disetujui</option>
                                            <option value="tidak disetujui">Tidak disetujui</option>
                                            <?php } ?>
                                            
                                        </select>
     </div>
                                    
                                        
                                    </div>
                                    <div class="modal-footer">
                                        <input type="hidden" name="k_nip_baru" value=""> 
                                        <input type="hidden" name="mrn_id" value=""> 
                                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                        <button type="submit" class="btn btn-primary">Submit</button>
                                    </div>
                                    </form>
                                </div>
                            </div>
                        </div>

<!-- sample modal content -->
                        <div class="modal fade" style="margin-top: 50px;" id="Exp21Modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel1">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content ">
                                    <div class="modal-header">
                                        <h4 class="modal-title" id="exampleModalLabel1">EDIT DATA</h4>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                    </div>
                                    <form method="post" action="Edit_file_nikah" id="experience21modal" enctype="multipart/form-data">
                                    <div class="modal-body">
                                                    <input type="hidden" name="test" value="1"> 
                                                    <div class="form-group">
                                                        <label>File Nikah</label>
                                                        <input type="file" name="file_url" class="form-control form-control-line working_period" value="" placeholder=""> 
                                                    </div>                                      
                                        
                                    </div>
                                    <div class="modal-footer">
                                        <input type="hidden" name="k_nip_baru" value=""> 
                                        <input type="hidden" name="mrn_id" value=""> 
                                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                        <button type="submit" class="btn btn-primary">Submit</button>
                                    </div>
                                    </form>
                                </div>
                            </div>
                        </div>

<div class="modal fade" style="margin-top: 50px;" id="Exp22Modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel1">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content ">
                                    <div class="modal-header">
                                        <h4 class="modal-title" id="exampleModalLabel1">EDIT DATA</h4>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                    </div>
                                    <form method="post" action="Edit_file_suamiistri" id="experience22modal" enctype="multipart/form-data">
                                    <div class="modal-body">
                                                    <input type="hidden" name="test" value="1"> 
                                                    <div class="form-group">
                                                        <label>File Akta</label>
                                                        <input type="file" name="file_url" class="form-control form-control-line working_period" value="" placeholder=""> 
                                                    </div>                                      
                                        
                                    </div>
                                    <div class="modal-footer">
                                        <input type="hidden" name="k_nip_baru" value=""> 
                                        <input type="hidden" name="id" value=""> 
                                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                        <button type="submit" class="btn btn-primary">Submit</button>
                                    </div>
                                    </form>
                                </div>
                            </div>
                        </div>

                    <div class="modal fade" style="margin-top: 50px;" id="Exp23Modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel1">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content ">
                                    <div class="modal-header">
                                        <h4 class="modal-title" id="exampleModalLabel1">EDIT DATA</h4>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                    </div>
                                    <form method="post" action="Edit_file_ortu" id="experience23modal" enctype="multipart/form-data">
                                    <div class="modal-body">
                                                    <input type="hidden" name="test" value="1"> 
                                                    <div class="form-group">
                                                        <label>File Akta</label>
                                                        <input type="file" name="file_url" class="form-control form-control-line working_period" value="" placeholder=""> 
                                                    </div>                                      
                                        
                                    </div>
                                    <div class="modal-footer">
                                        <input type="hidden" name="k_nip_baru" value=""> 
                                        <input type="hidden" name="id" value=""> 
                                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                        <button type="submit" class="btn btn-primary">Submit</button>
                                    </div>
                                    </form>
                                </div>
                            </div>
                        </div>


 
                    <div class="modal fade" style="margin-top: 50px;" id="Exp24Modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel1">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content ">
                                    <div class="modal-header">
                                        <h4 class="modal-title" id="exampleModalLabel1">EDIT DATA</h4>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                    </div>
                                    <form method="post" action="Edit_file_pddkn" id="experience24modal" enctype="multipart/form-data">
                                    <div class="modal-body">
                                                    <input type="hidden" name="test" value="1"> 
                                                    <div class="form-group">    
                                                        <label>File Akta</label>
                                                        <input type="file" name="file_url" class="form-control form-control-line working_period" value="" placeholder=""> 
                                                    </div>                                      
                                        
                                    </div>
                                    <div class="modal-footer">
                                        <input type="hidden" name="k_nip_baru" value=""> 
                                        <input type="hidden" name="id" value=""> 
                                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                        <button type="submit" class="btn btn-primary">Submit</button>
                                    </div>
                                    </form>
                                </div>
                            </div>
                        </div>

                           
                          <div class="modal fade" style="margin-top: 50px;" id="Edu3Modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel1">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content ">
                                    <div class="modal-header">
                                        <h4 class="modal-title" id="exampleModalLabel1">EDIT DATA</h4>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                    </div>
                                    <form method="post" action="Edit_dep" id="education3modal" enctype="multipart/form-data">
                                    <div class="modal-body">
                                                    <div class="form-group">
                                                        <label> Kode Satuan Area</label>
                                                        <input type="text" name="area_sat_kode" class="form-control form-control-line company_name" placeholder="" minlength="2" > 
                                                    </div>
                                                    <div class="form-group">
                                                        <label> Nama Satuan Area</label>
                                                        <input type="text" name="area_sat_nama" class="form-control form-control-line company_name" placeholder="" minlength="2" > 
                                                    </div>
                                                    <div class="form-group">
                                                        <label> Kode Area</label>
                                                        <input type="text" name="area_kode" class="form-control form-control-line company_name" placeholder="" minlength="2" > 
                                                    </div>
                                                    <div class="form-group">
                                                        <label> Nama Area</label>
                                                        <input type="text" name="area_nama" class="form-control form-control-line company_name" placeholder="" minlength="2" > 
                                                    </div>
                                                
                                    </div>
                                    <div class="modal-footer">
                                        
                                        <input type="hidden" name="area_id" value=""> 
                                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                        <button type="submit" class="btn btn-primary">Submit</button>
                                    </div>
                                    </form>
                                </div>
                            </div>
                        </div>


                        <!-- sample modal content -->
                        