<?php $this->load->view('backend/header'); ?>
<?php $this->load->view('backend/sidebar'); ?>
         <div class="page-wrapper">
            <!-- ============================================================== -->
            <!-- Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <br><br>
            <div class="row page-titles">
                <div class="col-md-5 align-self-center">
                    <h3 class="text-themecolor"><i class="fa fa-user-secret" aria-hidden="true"></i> MASTER PENSIUN PEGAWAI</h3>
                </div>
                <div class="col-md-7 align-self-center">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="javascript:void(0)">Beranda</a></li>
                        <li class="breadcrumb-item active">Data Pensiun</li>
                    </ol>
                </div>
            </div>
            <div class="message"></div>
            <div class="container-fluid">
                <div class="row m-b-10"> 
            
                </div>
                <div class="row">
                    <div class="col-12">
                        <div class="card card-outline-info">
                            <div class="card-header">
                                <h4 class="m-b-0 text-white"><i class="fa fa-user-o" aria-hidden="true"></i> Data Pensiun</h4>
                            </div>
                         
                            <div class="card-body">
                                <div class="table-responsive ">
                                    <table id="employees123" class="display nowrap table table-hover table-striped table-bordered" cellspacing="0" width="100%">
                                        <thead>
                                            <tr>
                                                <th>No</th>
                                                <th>Nama Pegawai</th>
                                                <th>NIP</th>
                                                <th>Jenis Kelamin </th>
                                                <th>Pensiun </th>
                                                <th>Status </th>
                                                <th>Peringatan Pensiun </th>
                                                
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                           <?php foreach($data as $value):
                                            if($this->session->userdata('k_akses')== 'ADMIN UPT'):
                                                if($this->session->userdata('k_satuan')!=$value->k_satuan):
                                                    continue;
                                                endif;
                                                
                                            endif;
                                            ?>
                                            <tr>
                                                <td><?php echo $value->k_id;?></td>
                                                <td>
                                                  <?php
                                                    $tanggalSekarang=date("Y-m-d");
                                                    $jumlahHari=date('Y-d-m', strtotime($value->k_tmt_pensiun));
                                                    $hasilkurang = strtotime($jumlahHari) -  strtotime($tanggalSekarang);
                                                    $hari = $hasilkurang/(60*60*24);
                                                    $m_hasil_kurang = $hasilkurang;
                                                    if($m_hasil_kurang<0)
                                                        $m_hasil_kurang*=-1;
                                                    $sisa_tahun = intval($m_hasil_kurang/(60*60*24*30*12));
                                                    $sisa_bulan = intval(($m_hasil_kurang-($sisa_tahun*(60*60*24*30*12)))/(60*60*24*30));
                                                    $sisa_hari = intval(($m_hasil_kurang-($sisa_tahun*(60*60*24*30*12)) - $sisa_bulan*(60*60*24*30))/(60*60*24));
                                                    $total = $hari - $hari - $hari;
                                          
                                                    ?>

                                                    <?php if($hari<'1'){

                                                        echo "$value->k_nama";
                                                        
                                                        $conn= mysqli_connect("localhost","root","");
                                                        mysqli_select_db($conn,"genhr");
                                                        $lama = 3;
                                                        $query = "UPDATE master_kar SET k_stakepeg ='Pensiun'  WHERE DATEDIFF(CURDATE(), k_tmt_pensiun) > $lama";
                                                        
                                                        $hasil = mysqli_query($conn, $query);
                                                        
                                                    }
                                                        else echo "<b>$value->k_nama</b>";
                                                    ?>
                                                    
                                                </td>
                                                <td><?php echo $value->k_nip_baru;?></td>
                                                <td><?php if($value->k_jk=='1'){echo 'Laki-Laki';}
                                                    else echo "Perempuan";
                                                ?></td>
                                                <td>
                                                    <?php $jumlahHari=date('Y-d-m', strtotime($value->k_tmt_pensiun));
                                                    echo "$jumlahHari";
                                                    ?></td>
                                                <td><?php echo $value->k_stakepeg;?></td>
                                                <td>
                                                <center>
                                                    <?php
                                                    $tanggalSekarang=date("Y-m-d");
                                                    $jumlahHari=date('Y-d-m', strtotime($value->k_tmt_pensiun));
                                                    
                                                    $hasilkurang = strtotime($jumlahHari) -  strtotime($tanggalSekarang);
                                                    $hari = $hasilkurang/(60*60*24);
                                                    $total = $hari - $hari - $hari;
                                                    
                                                    ?>

                                                    <?php if($hari<0){
                                                        echo "<button class='btn btn-sm btn-danger'>$sisa_tahun tahun $sisa_bulan bulan $sisa_hari hari yang lalu</div>";
                                                    }?>
                                                    

                                                <?php if($hari>0){
                                                   echo "<button class='btn btn-sm btn-info'>$sisa_tahun tahun $sisa_bulan bulan $sisa_hari hari lagi </div>";

                                                }?>
                                                <?php if($hari==0){
                                                   echo "<button class='btn btn-sm btn-danger'>Hari ini pensiun </div>";

                                                }
                                                ?>
                                                </center>
                                                </td>
                                                
                                                <td class="jsgrid-align-center ">
                                                    <a href="<?php echo base_url(); ?>employee/view?I=<?php echo base64_encode($value->k_nip_baru); ?>" title="Edit" class="btn btn-sm btn-info waves-effect waves-light"><i class="fa fa-pencil-square-o"></i></a>
                                                </td>
                                            </tr>
                                            <?php endforeach; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
<?php $this->load->view('backend/footer'); ?>
<script>
    $('#employees123').DataTable({
        "aaSorting": [[1,'asc']],
        dom: 'Bfrtip',
        buttons: [
            'copy', 'csv', 'excel', 'pdf', 'print'
        ]
    });
</script>