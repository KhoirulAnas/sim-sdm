<?php $this->load->view('backend/header'); ?>
<?php $this->load->view('backend/sidebar'); ?>

<?php
 $pendidikanvalue = $this->employee_model->getpddkn();
$connect = new PDO("mysql:host=localhost;dbname=genhr", "root", "");
$country = '';
$pddkn = '';
$query = "SELECT DISTINCT k_unit_kerja FROM master_kar ORDER BY k_id ASC";
$query2 = "SELECT DISTINCT pend_id FROM master_pendidikan ORDER BY pend_id ASC" ;
$statement = $connect->prepare($query);
$statement2 = $connect->prepare($query2);
$statement->execute();
$statement2->execute();
$result = $statement->fetchAll();
foreach($result as $row)
{
 $country .= '<option value="'.$row['k_unit_kerja'].'">'.$row['k_unit_kerja'].'</option>';

}
$result2 = $statement2->fetchAll();
foreach($result2 as $row)
{
 $pddkn .= '<option value="'.$row['pend_id'].'">'.$row['pend_id'].'</option>';

}


?>
         <div class="page-wrapper">
            <!-- ============================================================== -->
            <!-- Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <br><br><div class="row page-titles">
                <div class="col-md-5 align-self-center">
                    <h3 class="text-themecolor"><i class="fa fa-user-secret" aria-hidden="true"></i> FILTER DATA PEGAWAI</h3>
                </div>
                <div class="col-md-7 align-self-center">
                    <ol class="breadcrumb">
                        
                        <li class="breadcrumb-item active">Filter pegawai</li>
                    </ol>
                </div>
            </div>
            <div class="message"></div>
            <div class="container-fluid">
                <div class="row m-b-10"> 
                    
                </div>
                <div class="row">
                    <div class="col-12">
                        <div class="card card-outline-info">
                            <div class="card-header">
                                <h4 class="m-b-0 text-white"><i class="fa fa-user-o" aria-hidden="true"></i> Daftar Pegawai</h4>
                            </div>
                            <div class="form-group">
      <div class="col-md-4">
<br><div class="form-group">
        <select name="filter_gender" id="filter_gender" class="form-control" required>
       <option>Pilih Jenjang Pendidikan</option>
                                            <?Php foreach($pendidikanvalue as $value): ?>
                                            <option value="<?php echo $value->pend_id ?>"><?php echo $value->pend_jenjang ?></option>
                                            <?php endforeach; ?>
                                        </select>
     </div>
     <div class="form-group">
      <select name="filter_country" id="filter_country" class="form-control" required>
       <option value="">Pilih Unit Kerja</option>
       <?php echo $country; ?>
      </select>
     </div>
     
     <div class="form-group" align="center">
      <button type="button" name="filter" id="filter" class="btn btn-info">Filter</button>
     </div>
    </div></div>
                                   <div class="table-responsive">
    <table id="employees123" class="table table-bordered table-striped">
     <thead>
      <tr>
       <th width="2%">k_id</th>
       <th width="20%">Nama</th>
       <th width="5%">Jenis Kelamin</th>
       <th width="25%">UNIT KERJA</th>
       <th width="25%">NIK</th>
       <th width="25%">NIP</th>
       <th width="10%">Pendidikan</th>

      </tr>
     </thead>
    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/plugins/filter/jquery.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/plugins/filter/ddtf.js"></script>
<?php $this->load->view('backend/footer'); ?>
        <script>
            $(document).ready(function() {
                $("#BtnSubmit").on("click", function(event) {

                    event.preventDefault();

                    var area = $('#area').val();
                    var datetime = $('.mydatetimepicker').val();
                    console.log(datetime);
                    $.ajax({
                        url: "Get_LeaveDetails?area=" + area,
                        type: "GET",
                        data: 'data',
                        success: function(response) {
                            $('.leave').html(response);
                        }
                    });
                });
            });

        </script>
<script>
        $('#employees123').DataTable({

"aaSorting": [[1,'asc']],
        dom: 'Bfrtip',
        buttons: [
            'copy', 'csv', 'excel', 'pdf', 'print'
        ]
    "processing" : true,
    "serverSide" : true,
    
    "order" : [],

    "searching" : false,

    "ajax" : {
     url:"fetch",
     

     type:"POST",
     data:{
      filter_gender:filter_gender, filter_country:filter_country
     }
    }
    });            
        
    </script>

<script type="text/javascript" language="javascript" >
 $(document).ready(function(){
  
  fill_datatable();
  
  function fill_datatable(filter_gender = '', filter_country = '')
  {
   var dataTable = $('#employees123').DataTable({
    
    "processing" : true,
    "serverSide" : true,

    "order" : [],

    "searching" : true,

    "ajax" : {
     url:"fetch",
     

     type:"POST",
     data:{
      filter_gender:filter_gender, filter_country:filter_country
     }
    }
   });
  }
  
  $('#filter').click(function(){
   
   var filter_gender = $('#filter_gender').val();
   var filter_country = $('#filter_country').val();
   
   if(filter_gender != '' && filter_country != '' )
   {
    $('#employees123').DataTable().destroy();

    fill_datatable(filter_gender, filter_country);
   }
   else
   {
    alert('Select Both filter option');
    $('#employees123').DataTable().destroy();

    fill_datatable();
   }
  });
  
  
 });
 
</script>