<?php $this->load->view('backend/header'); ?> <?php
$this->load->view('backend/sidebar'); ?> <div class="page-wrapper"> <!--
============================================================== --> <!-- Bread
crumb and right sidebar toggle --> <!--
============================================================== --> <br><br>
<div class="row page-titles"> <div class="col-md-5 align-self-center"> <h3
class="text-themecolor"><i class="fa fa-university" aria-hidden="true"></i>
Tambah Pegawai</h3> </div> <div class="col-md-7 align-self-center"> <ol
class="breadcrumb"> <li class="breadcrumb-item"><a
href="javascript:void(0)">Beranda</a></li> <li class="breadcrumb-item
active">Tambah Pegawai</li> </ol> </div> </div> <div class="message"></div>
<?php $areavalue = $this->employee_model->getarea(); ?> <?php $satvalue =
$this->employee_model->getsat(); ?> <?php $jkvalue =
$this->employee_model->getjk(); ?> <?php $agamavalue =
$this->employee_model->getagama(); ?> <?php $kotavalue =
$this->employee_model->getkota(); ?> <?php $golvalue =
$this->employee_model->getpanggol(); ?> <?php $jenjabvalue =
$this->employee_model->getjenjab(); ?>
            
            <div class="container-fluid">
                <div class="row m-b-10"> 
                    <div class="col-12">
                        <button type="button" class="btn btn-info"><i class="fa fa-bars"></i><a href="<?php echo base_url(); ?>employee/Employees" class="text-white"><i class="" aria-hidden="true"></i>  Daftar Pegawai</a></button>
                    </div>
                </div>
               <div class="row">
                    <div class="col-12">
                        <div class="card card-outline-info">
                            <div class="card-header">
                                <h4 class="m-b-0 text-white"><i class="fa fa-user-o" aria-hidden="true"></i> Tambah Pegawai Baru<span class="pull-right " ></span></h4>
                            </div>
                            <?php echo validation_errors(); ?>
                               <?php echo $this->upload->display_errors(); ?>
                               
                               <?php echo $this->session->flashdata('formdata'); ?>
                               <?php echo $this->session->flashdata('feedback'); ?>
                            <div class="card-body">

                                <form class="row" method="post" action="Save" enctype="multipart/form-data">
                                    <div class="form-group col-md-7 m-t-20">
                                        <label>Nama Lengkap</label>
                                        <input type="text" name="k_nama" class="form-control form-control-line" placeholder="Nama Lengkap" minlength="2" required > 
                                    </div>
                                    <div class="form-group col-md-3 m-t-20"></div>
                                    <div class="form-group col-md-3 m-t-20">
                                        <label>Jenis Kelamin</label>
                                        <select name="jk" value="" class="form-control custom-select" required>
                                            <option>Pilih</option>
                                            <?Php foreach($jkvalue as $value): ?>
                                            <option value="<?php echo $value->mg_id ?>"><?php echo $value->mg_nama ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                    <div class="form-group col-md-7 m-t-20"></div>
                                    <div class="form-group col-md-5 m-t-20">
                                        <label>Nomor Induk Pegawai</label>
                                        <input type="text" name="k_nip_baru" class="form-control form-control-line" placeholder="NIP"> 
                                    </div>
                                    <div class="form-group col-md-5 m-t-20">
                                        <label>Nomor Induk Keluarga</label>
                                        <input type="text" name="k_nik" class="form-control form-control-line" placeholder="NIK"> 
                                    </div>
                                    <div class="form-group col-md-5 m-t-20">
                                        <label>Tempat Lahir </label>
                                        <select name="tlahir" value="" class="form-control custom-select" required>
                                            <option>Pilih Kota</option>
                                            <?Php foreach($kotavalue as $value): ?>
                                            <option value="<?php echo $value->lokasi_nama ?>"><?php echo $value->lokasi_nama ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                    
                                    <div class="form-group col-md-5 m-t-20">
                                        <label>Tanggal Lahir </label>
                                        <input type="date" name="tl" id="example-email2" class="form-control" placeholder="" required> 
                                    </div>

                                    <div class="form-group col-md-5 m-t-20">
                                        <label>Agama</label>
                                        <select name="agm" value="" class="form-control custom-select" required>
                                            <option>Pilih</option>
                                            <?Php foreach($agamavalue as $value): ?>
                                            <option value="<?php echo $value->ma_id ?>"><?php echo $value->ma_nama ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                    
                                    <div class="form-group col-md-5 m-t-20">
                                        <label>Status Nikah</label>
                                        <select name="snikah" value="" class="form-control custom-select" required>
                                            <option>Pilih</option>
                                            <option value="Menikah">Menikah</option>
                                            <option value="Belum Menikah">Belum Menikah</option>
                                            
                                        </select>
                                    </div>

                                    <div class="form-group col-md-10 m-t-20">
                                        <label>Alamat Domisili</label>
                                        <textarea name="alamat" class="form-control form-control-line" placeholder="Masukkan Alamat lengkap.." minlength="2" required> </textarea>
                                    </div>

                                    <div class="form-group col-md-10 m-t-20">
                                        <label>SATUAN AREA</label>
                                        <select id="sat" name="sat" value="" class="form-control custom-select" required>
                                            <option>Pilih Satuan Area</option>
                                            <?Php foreach($satvalue as $value): ?>
                                            <option value="<?php echo $value->satuan_kode ?>"><?php echo $value->satuan_nama ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                    <div class="form-group col-md-10 m-t-20">
                                        <label>AREA UPT </label>
                                        <select id="area" name="upt" value="" class="form-control custom-select" required>
                                        </select>
                                    </div>
                                    
                                    


                                    <div class="form-group col-md-5 m-t-20">
                                        <label>Pangkat Golongan</label>
                                        <select name="panggol" value="" class="form-control custom-select" required>
                                            <option>Pilih</option>
                                            <?Php foreach($golvalue as $value): ?>
                                            <option value="<?php echo $value->panggol_id ?>"><?php echo $value->panggol_pangkat ?> <b>(<?php echo $value->panggol_golru ?>)</b></option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>

                                    <div class="form-group col-md-5 m-t-20">
                                        <label>Jenis Jabatan</label>
                                        <select name="jenjab" value="" class="form-control custom-select" required>
                                            <option>Pilih</option>
                                            <?Php foreach($jenjabvalue as $value): ?>
                                            <option value="<?php echo $value->jenjab_id ?>"><?php echo $value->jenjab_nama ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                    

                                    <div class="form-group col-md-4 m-t-20">
                                        <label>TMT Jabatan </label>
                                        <input type="date" name="tmtj" id="example-email2" class="form-control" placeholder="" required> 
                                    </div>

                                    <div class="form-group col-md-4 m-t-20">
                                        <label>TMT Pensiun </label>
                                        <input type="date" name="tmtp" id="example-email2" class="form-control" placeholder="" required> 
                                    </div>
                                    <div class="form-group col-md-2 m-t-20"></div>
                                    
                                    
                                    <div class="form-group col-md-3 m-t-20">
                                        <label>Hak Akses</label>
                                        <select name="akses" value="" class="form-control custom-select" required>
                                            <option>Pilih</option>
                                            <option value="ADMIN">FASILITATOR</option>
                                            <option value="EMPLOYEE">PEGAWAI</option>
                                            <option value="ADMIN UPT">ADMIN UPT</option>
                                        </select>
                                    </div>
                                    <div class="form-group col-md-3 m-t-20">
                                        <label>Password </label>
                                        <input type="password" name="password" class="form-control" value="" placeholder=""> 
                                    </div>
                                    <div class="form-group col-md-3 m-t-20">
                                        <input type="hidden" name="stakepeg" class="form-control" value="Aktif" placeholder=""> 
                                    </div>
                                    <div class="form-actions col-md-12">
                                        <button type="submit" class="btn btn-info"> <i class="fa fa-check"></i> Simpan</button>
                                        <button type="button" class="btn btn-info">Batal</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                <?php $data['areavalue'] = $areavalue; ?>
<?php $this->load->view('backend/footer',$data); ?>