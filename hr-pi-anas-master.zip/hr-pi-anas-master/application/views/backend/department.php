<?php $this->load->view('backend/header'); ?>
<?php $this->load->view('backend/sidebar'); ?> 
         <div class="page-wrapper">
            <div class="row page-titles">
                <div class="col-md-5 align-self-center">
                    <h3 class="text-themecolor"><i class="fa fa-cubes" style="color:#000"></i> Pengelolaan Area</h3>
                </div>
                <div class="col-md-7 align-self-center">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
                        <li class="breadcrumb-item active">Pengelolaan Area</li>
                    </ol>
                </div>
            </div>
            <div class="message"></div> 
            <div class="container-fluid">         
                 <div class="row">
                    <div class="col-lg-6">
                        <?php if (isset($editdepartment)) { ?>
                        <div class="card card-outline-info">
                            <div class="card-header">
                                <h4 class="m-b-0 text-white">Edit Department</h4>
                            </div>
                            
                            <?php echo validation_errors(); ?>
                            <?php echo $this->upload->display_errors(); ?>
                            <?php echo $this->session->flashdata('feedback'); ?>
                            
                            <div class="card-body">
                                    <form method="post" action="<?php echo base_url();?>organization/Update_dep" enctype="multipart/form-data">
                                        <div class="form-body">
                                            <div class="row ">
                                                <div class="col-md-12">
                                                    <div class="form-group">
                                                        <label class="control-label">Department Name</label>
                                                        <input type="text" name="department" id="firstName" value="<?php  echo $editdepartment->dep_name;?>" class="form-control" placeholder="">
                                                        <input type="hidden" name="id" value="<?php  echo $editdepartment->id;?>">
                                                    </div>
                                                </div>
                                                <!--/span-->
                                            </div>
                                            <!--/row-->
                                        </div>
                                        <div class="form-actions">
                                            <button type="submit" class="btn btn-info"> <i class="fa fa-check"></i> Save</button>
                                            <button type="button" class="btn btn-info">Cancel</button>
                                        </div>
                                    </form>
                            </div>
                        </div>
                        <?php } else { ?>                        

                        <div class="card card-outline-info">
                            <div class="card-header">
                                <h4 class="m-b-0 text-white">Tambah Data</h4>
                            </div>
                            
                            <?php echo validation_errors(); ?>
                            <?php echo $this->upload->display_errors(); ?>
                            <?php echo $this->session->flashdata('feedback'); ?>
                            <div class="card-body">
                                    <form method="post" action="Save_dep" enctype="multipart/form-data">
                                        <div class="form-body">
                                            <div class="row ">
                                                <div class="col-md-10">
                                                    <div class="form-group ">
                                                        <label class="control-label">Kode Satuan Area</label>
                                                        <input type="text" name="area_sat_kode" id="area_sat_kode" value="" class="form-control" placeholder="" minlength="3" required>
                                                    </div>
                                                    <div class="form-group">
                                                        <label class="control-label">Nama Satuan Area</label>
                                                        <input type="text" name="area_sat_nama" id="area_sat_nama" value="" class="form-control" placeholder="" minlength="3" required>
                                                    </div>
                                                    <div class="form-group">
                                                        <label class="control-label">Kode Area</label>
                                                        <input type="text" name="area_kode" id="area_kode" value="" class="form-control" placeholder="" minlength="3" required>
                                                    </div>
                                                    <div class="form-group">
                                                        <label class="control-label">Nama Area</label>
                                                        <input type="text" name="area_nama" id="area_nama" value="" class="form-control" placeholder="" minlength="3" required>
                                                    </div>
                                                </div>
                                                <!--/span-->
                                            </div>
                                            <!--/row-->
                                        </div>
                                        <div class="form-actions">
                                            <button type="submit" class="btn btn-info"> <i class="fa fa-check"></i> Simpan</button>
                                            <button type="button" class="btn btn-info">Batalk</button>
                                        </div>
                                    </form>
                            </div>
                        </div>
                        <?php }?>
                    </div>

                    <div class="col-12">
                        <div class="card card-outline-info">
                            <div class="card-header">
                                <h4 class="m-b-0 text-white"> Master Area</h4>
                            </div>
                            <?php echo $this->session->flashdata('delsuccess'); ?>
                            <div class="card-body">
                                <div class="table-responsive ">
                                    <table id="" class="display  table table-hover table-striped table-bordered" cellspacing="0" width="100%">
                                        <thead>
                                            <tr>
                                                
                                                <th>Kode Satuan Area</th>
                                                <th>Nama Satuan Area</th>
                                                <th>Kode Area</th>
                                                <th>Nama Area</th>
                                                <center><th>Aksi</th></center>
                                            </tr>
                                        </thead>
                                            
                                        
                                        <tbody>
                                            
                                            <?php foreach ($department as $value): ?>
                                            <tr>
                                                
                                                <td><?php echo $value->area_sat_kode;?></td>
                                                <td><?php echo $value->area_sat_nama;?></td>
                                                <td><?php echo $value->area_kode;?></td>
                                                <td><?php echo $value->area_nama;?></td>
                                                <td class="jsgrid-align-center ">
                                                    <a href="#" title="Edit" class="btn btn-sm btn-info waves-effect waves-light education" data-id="<?php echo $value->area_id ?>"><i class="fa fa-pencil-square-o"></i></a>
                                                    <a onclick="return confirm('Apa anda yakin akan menghapus data?')"  href="<?php echo base_url();?>organization/dep_delete/<?php echo $value->area_id;?>" title="Delete" class="btn btn-sm btn-info waves-effect waves-light"><i class="fa fa-trash-o"></i></a>
                                                </td>
                                            </tr>
                                            
                                            
                                                
                                            <?php endforeach; ?>
                                            
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
    <?php $this->load->view('backend/footer'); ?>
    <?php $this->load->view('backend/em_modal'); ?>                
<script type="text/javascript">
                                        $(document).ready(function () {
                                            $(".education").click(function (e) {
                                                e.preventDefault(e);
                                                // Get the record's ID via attribute  
                                                var iid = $(this).attr('data-id');
                                                $('#education3modal').trigger("reset");
                                                $('#Edu3Modal').modal('show');
                                                $.ajax({
                                                    url: 'uptbyib?id=' + iid,
                                                    method: 'GET',
                                                    data: '',
                                                    dataType: 'json',
                                                }).done(function (response) {
                                                    console.log(response);
                                                    // Populate the form fields with the data returned from server
                                                    $('#education3modal').find('[name="area_id"]').val(response.uptvalue.area_id).end();
                                                    $('#education3modal').find('[name="area_sat_kode"]').val(response.uptvalue.area_sat_kode).end();
                                                    $('#education3modal').find('[name="area_sat_nama"]').val(response.uptvalue.area_sat_nama).end();
                                                    $('#education3modal').find('[name="area_kode"]').val(response.uptvalue.area_kode).end();
                                                    $('#education3modal').find('[name="area_nama"]').val(response.uptvalue.area_nama).end();
                                                });
                                            });
                                        });
</script>      

<script type="text/javascript">
                                        $(document).ready(function () {
                                            $(".education").click(function (e) {
                                                e.preventDefault(e);
                                                // Get the record's ID via attribute  
                                                var iid = $(this).attr('data-id');
                                                $('#education3modal').trigger("reset");
                                                $('#Edu3Modal').modal('show');
                                                $.ajax({
                                                    url: 'uptbyib?id=' + iid,
                                                    method: 'GET',
                                                    data: '',
                                                    dataType: 'json',
                                                }).done(function (response) {
                                                    console.log(response);
                                                    // Populate the form fields with the data returned from server
                                                    
                                                });
                                            });
                                        });
</script>                