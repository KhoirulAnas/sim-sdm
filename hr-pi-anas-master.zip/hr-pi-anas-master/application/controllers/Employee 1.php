<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Employee extends CI_Controller {

    /**
     * Index Page for this controller.
     *
     * Maps to the following URL
     *      http://example.com/index.php/welcome
     *  - or -
     *      http://example.com/index.php/welcome/index
     *  - or -
     * Since this controller is set as the default controller in
     * config/routes.php, it's displayed at http://example.com/
     *
     * So any other public methods not prefixed with an underscore will
     * map to /index.php/welcome/<method_name>
     * @see https://codeigniter.com/user_guide/general/urls.html
     */
    function __construct() {
        parent::__construct();
        $this->load->database();
        $this->load->model('dashboard_model');
        $this->load->model('employee_model');
        $this->load->model('login_model');
        $this->load->model('payroll_model');
        $this->load->model('settings_model');
        $this->load->model('leave_model');
  
    }
    
    public function index()
    {
        if ($this->session->userdata('user_login_access') != 1)
            redirect(base_url() . 'login', 'refresh');
        if ($this->session->userdata('user_login_access') == 1)
          $data= array();
        redirect('employee/Employees');
    }
    public function Employees(){
        if($this->session->userdata('user_login_access') != False) { 
        $data['employee'] = $this->employee_model->emselect();
        $this->load->view('backend/employees',$data);
        }
    else{
        redirect(base_url() , 'refresh');
    }        
    }
    public function filterupt(){
        if($this->session->userdata('user_login_access') != False) { 
        $data['employee'] = $this->employee_model->emselect();
        $this->load->view('backend/filterupt',$data);
        }
    else{
        redirect(base_url() , 'refresh');
    }        
    }
    public function pensiun(){
        if($this->session->userdata('user_login_access') != False) { 
        $data['data'] = $this->db->get('master_kar')->result();
        $data['employee'] = $this->employee_model->pensiun();
        $this->load->view('backend/pensiun',$data);
        }
    else{
        redirect(base_url() , 'refresh');
    }        
    }
    public function load_upt(){
        $unit_kerja = $_GET['unit_kerja'];
        if ($unit_kerja==0){
            $data=$this->db->get('master_kar')->result();
        }
        else
        {
            $data=$this->db->get_where('master_kar', ['k_jk'=>$unit_kerja])->result();    
        }
        if(!empty($data))                
        {
        foreach ($data as $value):?> 
           <tr>
           <td><?php echo $value->k_id;?></td>
                <td><?php echo $value->k_nama;?></td>
                <td><?php echo $value->k_nip_baru;?></td>
                <td><?php echo $value->k_nik;?></td>
                <td><?php echo $value->k_pendidikan;?></td>
                <td><?php if($value->k_jk=='1'){echo 'Laki-Laki';}
                else echo "Perempuan";?>
                </td>
                <td><?php echo $value->k_snikah;?></td>
                <td><?php echo $value->k_unit_kerja;?></td>
            </tr>
        <?php endforeach ?> <?php     
        }
        else
        {
                    ?>
                <tr><td align="center">Tidak ada data</td></tr>
            <?php
            
        }
    }
    public function load_upt2(){
        $k_pendidikan = $_GET['k_pendidikan'];
        if ($k_pendidikan==0){
            $data=$this->db->get('master_kar')->result();
        }
        else
        {
            $data=$this->db->get_where('master_kar', ['k_pendidikan'=>$k_pendidikan])->result();    
        }
        if(!empty($data))                
        {
        foreach ($data as $value):?> 
           <tr>
                <td><?php echo $value->k_id;?></td>
                <td><?php echo $value->k_nama;?></td>
                <td><?php echo $value->k_nip_baru;?></td>
                <td><?php echo $value->k_nik;?></td>
                <td><?php echo $value->k_pendidikan;?></td>
                <td><?php if($value->k_jk=='1'){echo 'Laki-Laki';}
                else echo "Perempuan";?>
                </td>
                <td><?php echo $value->k_snikah;?></td>
                <td><?php echo $value->k_unit_kerja;?></td>
            </tr>
        <?php endforeach ?> <?php     
        }
        else
        {
                    ?>
                <tr><td align="center">Tidak ada data</td></tr>
            <?php
            
        }
    }
    
    public function Add_employee(){
        if($this->session->userdata('user_login_access') != False) { 
        $this->load->view('backend/add-employee');
        }
    else{
        redirect(base_url() , 'refresh');
    }            
    }
    public function Save(){ 
    if($this->session->userdata('user_login_access') != False) {    
    
    $id = $this->input->post('k_nip_baru');    
    $k_nama = $this->input->post('k_nama');  
    $k_nip_baru = $this->input->post('k_nip_baru');
    $k_nik = $this->input->post('k_nik');
    $upt = $this->input->post('upt');
    $sat = $this->input->post('sat');
    $akses = $this->input->post('akses');
    $tlahir = $this->input->post('tlahir');
    $jk = $this->input->post('jk');
    $agm = $this->input->post('agm');
    $snikah = $this->input->post('snikah');
    $alamat = $this->input->post('alamat');
    $panggol = $this->input->post('panggol');
    $jenjab = $this->input->post('jenjab');
    $tl = $this->input->post('tl');
    $tmtj = $this->input->post('tmtj');
    $tmtp = $this->input->post('tmtp');
    $password = $this->input->post('password');
    $stakepeg = $this->input->post('stakepeg');
    $pass = md5($password);
         
        $this->load->library('form_validation');
        $this->form_validation->set_error_delimiters();
        $this->form_validation->set_rules('k_nama', 'k_nama', 'trim|required|min_length[1]|max_length[100]|xss_clean');
        $this->form_validation->set_rules('k_nik', 'k_nik', 'trim|required|min_length[1]|max_length[100]|xss_clean');
        if ($this->form_validation->run() == FALSE) {
            echo validation_errors();
            
            } else {
            if($_FILES['image_url']['name']){
            $file_name = $_FILES['image_url']['name'];
            $fileSize = $_FILES["image_url"]["size"]/1024;
            $fileType = $_FILES["image_url"]["type"];
            $new_file_name='';
            $new_file_name .= $file_name;

            $config = array(
                'file_name' => $new_file_name,
                'upload_path' => "./assets/images/users",
                'allowed_types' => "gif|jpg|png|jpeg|pdf|doc|docx|xml|text|txt",
                'overwrite' => False,
                'max_size' => "40480000"
            );
    
            $this->load->library('Upload', $config);
            $this->upload->initialize($config);                
            if (!$this->upload->do_upload('image_url')) {
                echo $this->upload->display_errors();
                #redirect("employee/view?I=" .base64_encode($em_id));
            }
   
            else {
                $path = $this->upload->data();
                $img_url = $path['file_name'];
                $data = array();
                $data = array(
                    'k_nama' => $k_nama,
                    'k_nip_baru' => $k_nip_baru,
                    'k_nik' => $k_nik,
                    'k_unit_kerja' => $upt,
                    'k_satuan' => $sat,
                    'k_tlahir' => $tlahir,
                    'k_jk' => $jk,
                    'k_agama' => $agm,
                    'k_snikah' => $snikah,
                    'k_alamat' => $alamat,
                    'k_golongan' => $panggol,
                    'k_jenis_jabatan' => $jenjab,
                    'k_tglahir' => $tl,
                    'k_tmt_jabatan' => $tmtj,
                    'k_tmt_pensiun' => $tmtp,
                    'k_pass' => $pass,
                    'k_akses' => $akses,
                    'k_stakepeg' => $stakepeg,
                    'k_foto' => $img_url
                );
            
            $success = $this->employee_model->Add($data,$id); 
            
            #$this->session->set_flashdata('feedback','Successfully Updated');
            #redirect("employee/view?I=" .base64_encode($em_id));
                echo "Berhasil tersimpan!";
            }
        }
            
        }
        }
    else{
        redirect(base_url() , 'refresh');
    }        
    }
    public function Update(){
    if($this->session->userdata('user_login_access') != False) {    
    
    $id = $this->input->post('k_nip_baru');    
    $k_nama = $this->input->post('k_nama');  
    $k_nip_baru = $this->input->post('k_nip_baru');
    $k_nik = $this->input->post('k_nik');
    $upt = $this->input->post('upt');
    $sat = $this->input->post('sat');
    $akses = $this->input->post('akses');
    $tlahir = $this->input->post('tlahir');
    $jk = $this->input->post('jk');
    $agm = $this->input->post('agm');
    $snikah = $this->input->post('snikah');
    $alamat = $this->input->post('alamat');
    $panggol = $this->input->post('panggol');
    $jenjab = $this->input->post('jenjab');
    $tl = $this->input->post('tl');
    $tmtj = $this->input->post('tmtj');
    $tmtp = $this->input->post('tmtp');
    $stakepeg = $this->input->post('stakepeg');
    
         
        $this->load->library('form_validation');
        $this->form_validation->set_error_delimiters();
        $this->form_validation->set_rules('k_nama', 'k_nama', 'trim|required|min_length[1]|max_length[100]|xss_clean');

        $this->form_validation->set_rules('k_nip_baru', 'k_nip_baru','trim|required|min_length[7]|max_length[100]|xss_clean');


               if ($this->form_validation->run() == FALSE) {
            echo validation_errors();
            #redirect("employee/view?I=" .base64_encode($eid));
            } else {
            if($_FILES['image_url']['name']){
            $file_name = $_FILES['image_url']['name'];
            $fileSize = $_FILES["image_url"]["size"]/1024;
            $fileType = $_FILES["image_url"]["type"];
            $new_file_name='';
            $new_file_name .= $id;

            $config = array(
                'file_name' => $new_file_name,
                'upload_path' => "./assets/images/users",
                'allowed_types' => "gif|jpg|png|jpeg",
                'overwrite' => False,
                'max_size' => "20240000", // Can be set to particular file size , here it is 2 MB(2048 Kb)
                'max_height' => "1600",
                'max_width' => "1600"
            );
    
            $this->load->library('Upload', $config);
            $this->upload->initialize($config);                
            if (!$this->upload->do_upload('image_url')) {
                echo $this->upload->display_errors();
                #redirect("employee/view?I=" .base64_encode($eid));
            }
   
            else {
            $employee = $this->employee_model->GetBasics($id);
            $checkimage = "./assets/images/users/$employee->k_foto";                 
                if(file_exists($checkimage)){
                unlink($checkimage);
                }
                $path = $this->upload->data();
                $img_url = $path['file_name'];
                $data = array();
                $data = array(
                     'k_nama' => $k_nama,
                    'k_nip_baru' => $k_nip_baru,
                    'k_nik' => $k_nik,
                    'k_unit_kerja' => $upt,
                    'k_satuan' => $sat,
                    'k_tlahir' => $tlahir,
                    'k_jk' => $jk,
                    'k_agama' => $agm,
                    'k_snikah' => $snikah,
                    'k_alamat' => $alamat,
                    'k_golongan' => $panggol,
                    'k_jenis_jabatan' => $jenjab,
                    'k_tglahir' => $tl,
                    'k_tmt_jabatan' => $tmtj,
                    'k_tmt_pensiun' => $tmtp,
                    'k_akses' => $akses,
                    'k_stakepeg' => $stakepeg,
                    'k_foto' => $img_url
                    
                );
                if($id){
            $success = $this->employee_model->Update($data,$id); 
            $this->session->set_flashdata('feedback','Successfully Updated');
            echo "Successfully Updated";
                }
            }
        } else {
                $data = array();
                $data = array(
                    'k_nama' => $k_nama,
                    'k_nip_baru' => $k_nip_baru,
                    'k_nik' => $k_nik,
                    'k_unit_kerja' => $upt,
                    'k_satuan' => $sat,
                    'k_tlahir' => $tlahir,
                    'k_jk' => $jk,
                    'k_agama' => $agm,
                    'k_snikah' => $snikah,
                    'k_alamat' => $alamat,
                    'k_golongan' => $panggol,
                    'k_jenis_jabatan' => $jenjab,
                    'k_tglahir' => $tl,
                    'k_tmt_jabatan' => $tmtj,
                    'k_tmt_pensiun' => $tmtp,
                    'k_akses' => $akses,
                    'k_stakepeg' => $stakepeg,
                    
                );
                if($id){
            $success = $this->employee_model->Update($data,$id); 
            $this->session->set_flashdata('feedback','Successfully Updated');
            echo "Successfully Updated";
                }
            }
        }
        }
    else{
        redirect(base_url() , 'refresh');
           }        
        }

    public function view(){
        if($this->session->userdata('user_login_access') != False) {
        $id = base64_decode($this->input->get('I'));
        $data['basic'] = $this->employee_model->GetBasic($id);
        $data['data'] = $this->employee_model->GetBasics($id);
        $data['basics'] = $this->employee_model->GetBasics($id);
        $data['present'] = $this->employee_model->GetpreAddress($id);
        $data['education'] = $this->employee_model->GetEducation($id);
        $data['experience'] = $this->employee_model->GetExperience($id);
        
        $data['nikah'] = $this->employee_model->GetBankInfo($id);
        $data['fileinfo'] = $this->employee_model->GetFileInfo($id);
        $data['anak'] = $this->employee_model->GetAnak($id);
        $data['nikah'] = $this->employee_model->GetNikah($id);
        $data['typevalue'] = $this->payroll_model->GetsalaryType();
        $data['leavetypes'] = $this->leave_model->GetleavetypeInfo();    
        $data['salaryvalue'] = $this->employee_model->GetsalaryValue($id);
        $data['socialmedia'] = $this->employee_model->GetSocialValue($id);
            $year = date('Y');
        $data['Leaveinfo'] = $this->employee_model->GetLeaveiNfo($id,$year);
        $this->load->view('backend/employee_view',$data);
        }
    else{
        redirect(base_url() , 'refresh');
    }         
    }
    public function Parmanent_Address(){
        if($this->session->userdata('user_login_access') != False) {
        $id = $this->input->post('id');
        $mrn_no_surat = $this->input->post('mrn_no_surat');
        $mrn_status = $this->input->post('mrn_status');
        $this->load->library('form_validation');
        $this->form_validation->set_error_delimiters();
        $this->form_validation->set_rules('paraddress', 'address', 'trim|required|min_length[5]|max_length[100]|xss_clean');

        if ($this->form_validation->run() == FALSE) {
            echo validation_errors();
            #redirect("employee/view?I=" .base64_encode($em_id));
            } else {
            $data = array();
                $data = array(
                    'k_id' => $k_id,
                    'city' => $parcity,
                    'country' => $parcountry,
                    'address' => $paraddress,
                    'type' => 'Permanent'
                );
            if(!empty($id)){
                $success = $this->employee_model->UpdateParmanent_Address($id,$data);
                $this->session->set_flashdata('feedback','Successfully Updated');
                echo "Successfully Updated";                
            } else {
                $success = $this->employee_model->AddParmanent_Address($data);
                $this->session->set_flashdata('feedback','Successfully Added');
                echo "Successfully Added";
            }
                       
        }
        }
    else{
        redirect(base_url() , 'refresh');
    }             
    }
    //digunakan untuk delete 
    public function suamiistri_delete($id){
        if($this->session->userdata('user_login_access') != False) { 
        $this->employee_model->suamiistri_delete($id);
        $this->session->set_flashdata('delsuccess');
        echo "<script>alert('Berhasil Dihapus!');history.go(-1);</script>";
        
        }
    else{
        redirect(base_url() , 'refresh');
    }            
    }

    public function anak_delete($id){
        if($this->session->userdata('user_login_access') != False) { 
        $this->employee_model->anak_delete($id);
        $this->session->set_flashdata('delsuccess');
        echo "<script>alert('Berhasil Dihapus!');history.go(-1);</script>";
        
        }
    else{
        redirect(base_url() , 'refresh');
    }            
    }

    public function nikah_delete($id){
        if($this->session->userdata('user_login_access') != False) { 
        $this->employee_model->nikah_delete($id);
        $this->session->set_flashdata('delsuccess');
        echo "<script>alert('Berhasil Dihapus!');history.go(-1);</script>";
        
        }
    else{
        redirect(base_url() , 'refresh');
    }            
    }
    public function Present_Address(){
        if($this->session->userdata('user_login_access') != False) {
        $id = $this->input->post('id');
        $em_id = $this->input->post('emid');
        $presaddress = $this->input->post('presaddress');
        $prescity = $this->input->post('prescity');
        $prescountry = $this->input->post('prescountry');
        $this->load->library('form_validation');
        $this->form_validation->set_error_delimiters();
        $this->form_validation->set_rules('presaddress', 'address', 'trim|required|min_length[5]|max_length[100]|xss_clean');

        if ($this->form_validation->run() == FALSE) {
            echo validation_errors();
            #redirect("employee/view?I=" .base64_encode($em_id));
            } else {
            $data = array();
                $data = array(
                    'emp_id' => $em_id,
                    'city' => $prescity,
                    'country' => $prescountry,
                    'address' => $presaddress,
                    'type' => 'Present'
                );
            if(empty($id)){
                $success = $this->employee_model->AddParmanent_Address($data);
                $this->session->set_flashdata('feedback','Successfully Added');
                echo "Successfully Updated";
            } else {
                $success = $this->employee_model->UpdateParmanent_Address($id,$data);
                $this->session->set_flashdata('feedback','Successfully Updated');
                echo "Successfully Added";
            }
                       
        }
        }
    else{
        redirect(base_url() , 'refresh');
    }        
    }
    public function Add_Education(){
        if($this->session->userdata('user_login_access') != False) {
        $id = $this->input->post('id');
        $k_id = $this->input->post('k_id');
        $pend_id = $this->input->post('pend_id');
        $pend_jenjab = $this->input->post('pend_jenjab');
        
        $this->load->library('form_validation');
        $this->form_validation->set_error_delimiters();
        
        $this->form_validation->set_rules('an_nik', 'an_nik', 'trim|required|min_length[1]|max_length[250]|xss_clean');

        if ($this->form_validation->run() == FALSE) {
            echo validation_errors();
            #redirect("employee/view?I=" .base64_encode($em_id));
            } else {
            $data = array();
                $data = array(
                    'emp_id' => $em_id,
                    'edu_type' => $certificate,
                    'institute' => $institute,
                    'result' => $eduresult,
                    'year' => $eduyear
                );
            if(empty($id)){
                $success = $this->employee_model->Add_education($data);
                $this->session->set_flashdata('feedback','Successfully Added');
                echo "Successfully Added";
            } else {
                $success = $this->employee_model->Update_Education($id,$data);
                #$this->session->set_flashdata('feedback','Successfully Updated');
                echo "Successfully Updated";
            }
                       
        }
        }
    else{
        redirect(base_url() , 'refresh');
    }            
    }
    public function Save_Social(){
        if($this->session->userdata('user_login_access') != False) {
        $id = $this->input->post('id');
        $em_id = $this->input->post('emid');
        $facebook = $this->input->post('facebook');
        $twitter = $this->input->post('twitter');
        $google = $this->input->post('google');
        $skype = $this->input->post('skype');
        $this->load->library('form_validation');
        $this->form_validation->set_error_delimiters();
        $this->form_validation->set_rules('facebook', 'company_name', 'trim|xss_clean');

        if ($this->form_validation->run() == FALSE) {
            echo validation_errors();
            } else {
            $data = array();
                $data = array(
                    'emp_id' => $em_id,
                    'facebook' => $facebook,
                    'twitter' => $twitter,
                    'google_plus' => $google,
                    'skype_id' => $skype
                );
            if(empty($id)){
                $success = $this->employee_model->Insert_Media($data);
                echo "Successfully Added";
            } else {
                $success = $this->employee_model->Update_Media($id,$data);
                echo "Successfully Updated";
            }
                       
        }
        }
    else{
        redirect(base_url() , 'refresh');
    }        
    }
    public function Add_Experience(){
        if($this->session->userdata('user_login_access') != False) {
        
        $id = $this->input->post('id');
        $k_nip_baru = $this->input->post('k_nip_baru');
        $pas_nama = $this->input->post('pas_nama');
        $pas_nik = $this->input->post('pas_nik');
        $pas_stat = $this->input->post('pas_stat');
        $pas_tmpt = $this->input->post('pas_tmpt');
        
        
        $this->load->library('form_validation');
        $this->form_validation->set_error_delimiters();
        

        if ($this->form_validation->run() == FALSE) {
            echo validation_errors();
            #redirect("employee/view?I=" .base64_encode($em_id));
            } else {
            $data = array();
                $data = array(
                    'k_nip_baru' => $k_nip_baru,
                    'pas_nama' => $pas_nama,
                    'pas_stat' => $pas_stat,
                    'pas_tmpt' => $pas_tmpt,
                    'pas_nik' => $pas_nik
                );
            if(empty($id)){
                $success = $this->employee_model->Add_Experience($data);
                $this->session->set_flashdata('feedback','Successfully Added');
                echo "Successfully Updated";
            } else {
                $success = $this->employee_model->Update_Experience($id,$data);
                #$this->session->set_flashdata('feedback','Successfully Updated');
                echo "Successfully Updated";
            }
                       
        }
        }
    else{
        redirect(base_url() , 'refresh');
    }        
    }

    public function Disciplinary(){
        if($this->session->userdata('user_login_access') != False) {
        $data['desciplinary'] = $this->employee_model->desciplinaryfetch();
        $this->load->view('backend/disciplinary',$data); 
        }
    else{
        redirect(base_url() , 'refresh');
    }            
    }
    public function add_Desciplinary(){
        if($this->session->userdata('user_login_access') != False) {
        $id = $this->input->post('id');
        $em_id = $this->input->post('emid');
        $warning = $this->input->post('warning');
        $title = $this->input->post('title');
        $details = $this->input->post('details');
        $this->load->library('form_validation');
        $this->form_validation->set_error_delimiters();
        $this->form_validation->set_rules('title', 'title', 'trim|required|min_length[5]|max_length[150]|xss_clean');
        $this->form_validation->set_rules('details', 'details', 'trim|xss_clean');

        if ($this->form_validation->run() == FALSE) {
            echo validation_errors();
            #redirect('Disciplinary');
            } else {
            $data = array();
                $data = array(
                    'em_id' => $em_id,
                    'action' => $warning,
                    'title' => $title,
                    'description' => $details
                );
            if(empty($id)){
                $success = $this->employee_model->Add_Desciplinary($data);
                $this->session->set_flashdata('feedback','Successfully Added');
                #redirect('employee/Disciplinary');
                echo "Successfully Added";
            } else {
                $success = $this->employee_model->Update_Desciplinary($id,$data);
                #$this->session->set_flashdata('feedback','Successfully Updated');
                #redirect("employee/view?I=" .base64_encode($em_id));
                echo "Successfully Updated";
            }
                       
        }
        }
    else{
        redirect(base_url() , 'refresh');
    }        
    }
    public function Add_bank_info(){
        if($this->session->userdata('user_login_access') != False) {
        
        $mrn_id = $this->input->post('mrn_id');
        $k_nip_baru = $this->input->post('k_nip_baru');
        $mrn_no_surat = $this->input->post('mrn_no_surat');
        $mrn_tgl_nikah = $this->input->post('mrn_tgl_nikah');
        $mrn_status = $this->input->post('mrn_status');

        $this->load->library('form_validation');
        $this->form_validation->set_error_delimiters();
        $this->form_validation->set_rules('k_nip_baru', 'k_nip_baru', 'trim|required|min_length[5]|max_length[120]|xss_clean');
        

        if ($this->form_validation->run() == FALSE) {
            echo validation_errors();
            redirect("employee/view?I=" .base64_encode($k_nip_baru));
            } else {
            $data = array();
                $data = array(
                    'k_nip_baru' => $k_nip_baru,
                    'mrn_no_surat' => $mrn_no_surat,
                    'mrn_tgl_nikah' => $mrn_tgl_nikah,
                    'mrn_status' => $mrn_status
                );
            if(empty($id)){
                $success = $this->employee_model->Add_BankInfo($data);
                #$this->session->set_flashdata('feedback','Successfully Added');
                #redirect("employee/view?I=" .base64_encode($em_id));
                echo "Successfully Added";
            } else {
                $success = $this->employee_model->Update_BankInfo($id,$data);
                #$this->session->set_flashdata('feedback','Successfully Updated');
                #redirect("employee/view?I=" .base64_encode($em_id));
                echo "Successfully Updated";
            }
                       
        }
        }
    else{
        redirect(base_url() , 'refresh');
    }            
    }
    public function Reset_Password_Hr(){
        if($this->session->userdata('user_login_access') != False) {
        $id = $this->input->post('emid');
        $onep = $this->input->post('new1');
        $twop = $this->input->post('new2');
            if($onep == $twop){
                $data = array();
                $data = array(
                    'em_password'=> sha1($onep)
                );
        $success = $this->employee_model->Reset_Password($id,$data);
        #$this->session->set_flashdata('feedback','Successfully Updated');
        #redirect("employee/view?I=" .base64_encode($id));
                echo "Successfully Updated";
            } else {
        $this->session->set_flashdata('feedback','Please enter valid password');
        #redirect("employee/view?I=" .base64_encode($id)); 
                echo "Please enter valid password";
            }

        }
    else{
        redirect(base_url() , 'refresh');
    }        
    }
    public function Reset_Password(){
        if($this->session->userdata('user_login_access') != False) {
        $id = $this->input->post('k_nip_baru');
        $onep = $this->input->post('new1');
        $twop = $this->input->post('new2');
        $pass = md5($onep);
        $this->form_validation->set_rules('new1', 'new1', 'trim|required|min_length[5]|max_length[120]|xss_clean');
                    echo validation_errors();
            if($onep == $twop){
                $data = array();
                $data = array(
                    'k_pass'=> $pass
                );
        $success = $this->employee_model->Reset_Password($id,$data);
        #$this->session->set_flashdata('feedback','Successfully Updated');
        #redirect("employee/view?I=" .base64_encode($id));
                echo "Successfully Updated";
            } else {
        $this->session->set_flashdata('feedback','Please enter valid password');
        #redirect("employee/view?I=" .base64_encode($id)); 
                echo "Please enter valid password";
            }

        }
    else{
        redirect(base_url() , 'refresh');
    }        
    }
    public function Department(){
        if($this->session->userdata('user_login_access') != False) {
        $data['department'] = $this->employee_model->depselect();
        $this->load->view('backend/department',$data);
        }
    else{
        redirect(base_url() , 'refresh');
    }            
    }
    public function Save_dep(){
        if($this->session->userdata('user_login_access') != False) {
       $dep = $this->input->post('department');
       $this->load->library('form_validation');
       $this->form_validation->set_error_delimiters();
       $this->form_validation->set_rules('department','department','trim|required|xss_clean');

       if ($this->form_validation->run() == FALSE) {
           echo validation_errors();
           redirect('employee/Department');
       }else{
        $data = array();
        $data = array('dep_name' => $dep);
        $success = $this->employee_model->Add_Department($data);
        #$this->session->set_flashdata('feedback','Successfully Added');
        #redirect('employee/Department');
       }
        }
    else{
        redirect(base_url() , 'refresh');
    }        
    }
    public function Designation(){
        if($this->session->userdata('user_login_access') != False) {
        $data['designation'] = $this->employee_model->desselect();
        $this->load->view('backend/designation',$data);
        }
    else{
        redirect(base_url() , 'refresh');
    }            
    }
    public function Des_Save(){
        if($this->session->userdata('user_login_access') != False) {
        $des = $this->input->post('designation');
        $this->load->library('form_validation');
        $this->form_validation->set_error_delimiters();
        $this->form_validation->set_rules('designation','designation','trim|required|xss_clean');

        if ($this->form_validation->run() == FALSE) {
            echo validation_errors();
            redirect('employee/Designation');
        }else{
            $data = array();
            $data = array('des_name' => $des);
            $success = $this->employee_model->Add_Designation($data);
            $this->session->set_flashdata('feedback','Successfully Added');
            redirect('employee/Designation');
        }
        }
    else{
        redirect(base_url() , 'refresh');
    }
    }
    public function Assign_leave(){
        if($this->session->userdata('user_login_access') != False) {
        $emid = $this->input->post('em_id');
        $type = $this->input->post('typeid');
        $day = $this->input->post('noday');
        $year = $this->input->post('year');
        $this->load->library('form_validation');
        $this->form_validation->set_error_delimiters();
        $this->form_validation->set_rules('typeid','typeid','trim|required|xss_clean');

        if ($this->form_validation->run() == FALSE) {
            echo validation_errors();
            #redirect('employee/Designation');
        }else{
            $data = array();
            $data = array(
                'emp_id' => $emid,
                'type_id' => $type,
                'day' => $day,
                'total_day' => '0',
                'year' => $year
            );
            $success = $this->employee_model->Add_Assign_Leave($data);
            echo "Successfully Added";
        }
        }
    else{
        redirect(base_url() , 'refresh');
    }
    }
    
    public function Add_File(){
    if($this->session->userdata('user_login_access') != False) { 
    $k_nip_baru = $this->input->post('k_nip_baru');           
    $pas_nama = $this->input->post('pas_nama');           
    $pas_nik = $this->input->post('pas_nik');           
    $pas_stat = $this->input->post('pas_stat');           
    $pas_tmpt = $this->input->post('pas_tmpt');           
        
        $this->load->library('form_validation');
        $this->form_validation->set_error_delimiters();
        $this->form_validation->set_rules('pas_nama', 'pas_nama', 'trim|required|min_length[1]|max_length[120]|xss_clean');

        if ($this->form_validation->run() == FALSE) {
            echo validation_errors();
            
            } else {
            if($_FILES['file_url']['name']){
            $file_name = $_FILES['file_url']['name'];
            $fileSize = $_FILES["file_url"]["size"]/1024;
            $fileType = $_FILES["file_url"]["type"];
            $new_file_name='';
            $new_file_name .= $file_name;

            $config = array(
                'file_name' => $new_file_name,
                'upload_path' => "./assets/images/users",
                'allowed_types' => "gif|jpg|png|jpeg|pdf|doc|docx|xml|text|txt",
                'overwrite' => False,
                'max_size' => "40480000"
            );
    
            $this->load->library('Upload', $config);
            $this->upload->initialize($config);                
            if (!$this->upload->do_upload('file_url')) {
                echo $this->upload->display_errors();
                #redirect("employee/view?I=" .base64_encode($em_id));
            }
   
            else {
                $path = $this->upload->data();
                $img_url = $path['file_name'];
                $data = array();
                $data = array(
                    'k_nip_baru' => $k_nip_baru,
                    'pas_nama' => $pas_nama,
                    'pas_nik' => $pas_nik,
                    'pas_stat' => $pas_stat,
                    'pas_tmpt' => $pas_tmpt,
                    'file_url' => $img_url
                );
            $success = $this->employee_model->File_Upload($data); 
            #$this->session->set_flashdata('feedback','Successfully Updated');
            #redirect("employee/view?I=" .base64_encode($em_id));
                echo "Successfully Updated";
            }
        }
            
        }
        }
    else{
        redirect(base_url() , 'refresh');
    }        
    }
    public function Add_Nikah(){
    if($this->session->userdata('user_login_access') != False) { 
    $k_nip_baru = $this->input->post('k_nip_baru');           
    $no = $this->input->post('no');           
    $status = $this->input->post('status');           
    $tn = $this->input->post('tn');           
    
        $this->load->library('form_validation');
        $this->form_validation->set_error_delimiters();
        $this->form_validation->set_rules('no', 'no', 'trim|required|min_length[1]|max_length[120]|xss_clean');

        if ($this->form_validation->run() == FALSE) {
            echo validation_errors();
            
            } else {
            if($_FILES['file_url']['name']){
            $file_name = $_FILES['file_url']['name'];
            $fileSize = $_FILES["file_url"]["size"]/1024;
            $fileType = $_FILES["file_url"]["type"];
            $new_file_name='';
            $new_file_name .= $file_name;

            $config = array(
                'file_name' => $new_file_name,
                'upload_path' => "./assets/images/users",
                'allowed_types' => "gif|jpg|png|jpeg|pdf|doc|docx|xml|text|txt",
                'overwrite' => False,
                'max_size' => "40480000"
            );
    
            $this->load->library('Upload', $config);
            $this->upload->initialize($config);                
            if (!$this->upload->do_upload('file_url')) {
                echo $this->upload->display_errors();
                #redirect("employee/view?I=" .base64_encode($em_id));
            }
   
            else {
                $path = $this->upload->data();
                $img_url = $path['file_name'];
                $data = array();
                $data = array(
                    'k_nip_baru' => $k_nip_baru,
                    'mrn_no_surat' => $no,
                    'mrn_status' => $status,
                    'mrn_tgl_nikah' => $tn,
                    'file_url' => $img_url
                );
            $success = $this->employee_model->Nikah_Upload($data); 
            #$this->session->set_flashdata('feedback','Successfully Updated');
            #redirect("employee/view?I=" .base64_encode($em_id));
                echo "Successfully Updated";
            }
        }
            
        }
        }
    else{
        redirect(base_url() , 'refresh');
    }        
    }
    public function Add_Anak(){
    if($this->session->userdata('user_login_access') != False) { 
    $k_nip_baru = $this->input->post('k_nip_baru');           
    $nama = $this->input->post('nama');           
    $nik = $this->input->post('nik');           
    $stat = $this->input->post('stat');           
    $tlahir = $this->input->post('tmpt');           
    $pek = $this->input->post('pek');   
        
        $this->load->library('form_validation');
        $this->form_validation->set_error_delimiters();
        $this->form_validation->set_rules('nama', 'nama', 'trim|required|min_length[1]|max_length[120]|xss_clean');

        if ($this->form_validation->run() == FALSE) {
            echo validation_errors();
            
            } else {
            if($_FILES['file_url']['name']){
            $file_name = $_FILES['file_url']['name'];
            $fileSize = $_FILES["file_url"]["size"]/1024;
            $fileType = $_FILES["file_url"]["type"];
            $new_file_name='';
            $new_file_name .= $file_name;

            $config = array(
                'file_name' => $new_file_name,
                'upload_path' => "./assets/images/users",
                'allowed_types' => "gif|jpg|png|jpeg|pdf|doc|docx|xml|text|txt",
                'overwrite' => False,
                'max_size' => "40480000"
            );
    
            $this->load->library('Upload', $config);
            $this->upload->initialize($config);                
            if (!$this->upload->do_upload('file_url')) {
                echo $this->upload->display_errors();
                #redirect("employee/view?I=" .base64_encode($em_id));
            }
   
            else {
                $path = $this->upload->data();
                $img_url = $path['file_name'];
                $data = array();
                $data = array(
                    'k_nip_baru' => $k_nip_baru,
                    'an_nama' => $nama,
                    'an_nik' => $nik,
                    'an_stat' => $stat,
                    'an_tlahir' => $tlahir,
                    'an_pek' => $pek,
                    'file_url' => $img_url
                );
            $success = $this->employee_model->Anak_Upload($data); 
            #$this->session->set_flashdata('feedback','Successfully Updated');
            #redirect("employee/view?I=" .base64_encode($em_id));
                echo "Successfully Updated";
            }
        }
            
        }
        }
    else{
        redirect(base_url() , 'refresh');
    }        
    }

      public function Edit_suamiistri(){
    if($this->session->userdata('user_login_access') != False) { 
    $id = $this->input->post('id');
        $k_nip_baru = $this->input->post('k_nip_baru');
        $pas_nama = $this->input->post('pas_nama');
        $pas_nik = $this->input->post('pas_nik');
        $pas_stat = $this->input->post('pas_stat');
        $pas_tmpt = $this->input->post('pas_tmpt');
        
        $this->load->library('form_validation');
        $this->form_validation->set_error_delimiters();
        $this->form_validation->set_rules('pas_nama', 'pas_nama', 'trim|required|min_length[1]|max_length[120]|xss_clean');

        if ($this->form_validation->run() == FALSE) {
            echo validation_errors();
            
            }else {
                
                $data = array();
                $data = array(
                  'k_nip_baru' => $k_nip_baru,
                    'pas_nama' => $pas_nama,
                    'pas_stat' => $pas_stat,
                    'pas_tmpt' => $pas_tmpt,
                    'pas_nik' => $pas_nik
                );
           if(empty($id)){
                $success = $this->employee_model->Update_Experience($id,$data);
                echo "Successfully Added";
            } else {
                $success = $this->employee_model->Update_Experience($id,$data);
                echo "Successfully Updated";
            }
        }
        }
    else{
        redirect(base_url() , 'refresh');
    }        
    }
    public function Edit_Ortu(){
    if($this->session->userdata('user_login_access') != False) { 
    $id = $this->input->post('id');
    $k_nip_baru = $this->input->post('k_nip_baru');           
    $nama = $this->input->post('nama');           
    $nik = $this->input->post('nik');           
    $pek = $this->input->post('pek');           
    $stat = $this->input->post('stat');           
    $tlahir = $this->input->post('tlahir');
    
        
        $this->load->library('form_validation');
        $this->form_validation->set_error_delimiters();
        $this->form_validation->set_rules('nama', 'nama', 'trim|required|min_length[1]|max_length[120]|xss_clean');

        if ($this->form_validation->run() == FALSE) {
            echo validation_errors();
            
            }else {
                
                $data = array();
                $data = array(
                    'k_nip_baru' => $k_nip_baru,
                    'an_nama' => $nama,
                    'an_nik' => $nik,
                    'an_pek' => $pek,
                    'an_tlahir' => $tlahir,
                    'an_stat' => $stat
                );
           if(empty($id)){
                $success = $this->employee_model->Edit_Anak($id,$data);
                echo "Successfully Added";
            } else {
                $success = $this->employee_model->Edit_Anak($id,$data);
                echo "Successfully Updated";
            }
        }
        }
    else{
        redirect(base_url() , 'refresh');
    }        
    }

    public function anakbyib(){
        if($this->session->userdata('user_login_access') != False) {  
        $id= $this->input->get('id');
        $data['anakvalue'] = $this->employee_model->GetAnakValue($id);
        echo json_encode($data);
        }
    else{
        redirect(base_url() , 'refresh');
    } 
        
    }
    public function suamiistribyib(){
        if($this->session->userdata('user_login_access') != False) {  
        $id= $this->input->get('id');
        $data['suamiistrivalue'] = $this->employee_model->GetSuamiistriValue($id);
        echo json_encode($data);
        }
    else{
        redirect(base_url() , 'refresh');
    } 
        
    }
    public function experiencebyib(){
        if($this->session->userdata('user_login_access') != False) {  
        $id= $this->input->get('id');
        $data['expvalue'] = $this->employee_model->GetExpValue($id);
        echo json_encode($data);
        }
    else{
        redirect(base_url() , 'refresh');
    } 
        
    }
    public function DisiplinaryByID(){
        if($this->session->userdata('user_login_access') != False) {  
        $id= $this->input->get('id');
        $data['desipplinary'] = $this->employee_model->GetDesValue($id);
        echo json_encode($data);
        }
    else{
        redirect(base_url() , 'refresh');
    } 
        
    }
    public function EduvalueDelet(){
        if($this->session->userdata('user_login_access') != False) {  
        $id= $this->input->get('id');
        $success = $this->employee_model->DeletEdu($id);
        echo "Successfully Deletd";
        }
    else{
        redirect(base_url() , 'refresh');
    } 
    }
    public function EXPvalueDelet(){
        if($this->session->userdata('user_login_access') != False) {  
        $id= $this->input->get('id');
        $success = $this->employee_model->DeletEXP($id);
        echo "Successfully Deletd";
        }
    else{
        redirect(base_url() , 'refresh');
    } 
    }
    public function DeletDisiplinary(){
        if($this->session->userdata('user_login_access') != False) {  
        $id= $this->input->get('D');
        $success = $this->employee_model->DeletDisiplinary($id);
        #echo "Successfully Deletd";
            redirect('employee/Disciplinary');
        }
    else{
        redirect(base_url() , 'refresh');
    } 
    }
    public function Add_Salary(){
        if($this->session->userdata('user_login_access') != False) { 
        $sid = $this->input->post('sid');
        $aid = $this->input->post('aid');
        $did = $this->input->post('did');
        $em_id = $this->input->post('emid');
        $type = $this->input->post('typeid');
        $total = $this->input->post('total');
        $basic = $this->input->post('basic');
        $medical = $this->input->post('medical');
        $houserent = $this->input->post('houserent');
        $conveyance = $this->input->post('conveyance');
        $provident = $this->input->post('provident');
        $bima = $this->input->post('bima');
        $tax = $this->input->post('tax');
        $others = $this->input->post('others');
        $this->load->library('form_validation');
        $this->form_validation->set_error_delimiters();
        $this->form_validation->set_rules('total', 'total', 'trim|required|min_length[3]|max_length[10]|xss_clean');

        if ($this->form_validation->run() == FALSE) {
            echo validation_errors();
            #redirect("employee/view?I=" .base64_encode($em_id));
            } else {
            $data = array();
                $data = array(
                    'emp_id' => $em_id,
                    'type_id' => $type,
                    'total' => $total
                );
            if(!empty($sid)){
                $success = $this->employee_model->Update_Salary($sid,$data);
                #$this->session->set_flashdata('feedback','Successfully Updated');
                #echo "Successfully Updated";
                #$success = $this->employee_model->Add_Salary($data);
                #$insertId = $this->db->insert_id();
                #$this->session->set_flashdata('feedback','Successfully Added');
                #echo "Successfully Added";
                if(!empty($aid)){
                $data1 = array();
                $data1 = array(
                    'salary_id' => $sid,
                    'basic' => $basic,
                    'medical' => $medical,
                    'house_rent' => $houserent,
                    'conveyance' => $conveyance
                );
                $success = $this->employee_model->Update_Addition($aid,$data1);                    
                }
                if(!empty($did)){
                 $data2 = array();
                $data2 = array(
                    'salary_id' => $sid,
                    'provident_fund' => $provident,
                    'bima' => $bima,
                    'tax' => $tax,
                    'others' => $others
                );
                $success = $this->employee_model->Update_Deduction($did,$data2);                    
                }

                echo "Successfully Updated";                
            } else {
                $success = $this->employee_model->Add_Salary($data);
                $insertId = $this->db->insert_id();
                #$this->session->set_flashdata('feedback','Successfully Added');
                #echo "Successfully Added";
                $data1 = array();
                $data1 = array(
                    'salary_id' => $insertId,
                    'basic' => $basic,
                    'medical' => $medical,
                    'house_rent' => $houserent,
                    'conveyance' => $conveyance
                );
                $success = $this->employee_model->Add_Addition($data1);
                $data2 = array();
                $data2 = array(
                    'salary_id' => $insertId,
                    'provident_fund' => $provident,
                    'bima' => $bima,
                    'tax' => $tax,
                    'others' => $others
                );
                $success = $this->employee_model->Add_Deduction($data2); 
                echo "Successfully Added";
            }           
        }
        }
    else{
        redirect(base_url() , 'refresh');
    }        
    }
    public function confirm_mail_send($email,$pass_hash){
        $config = Array( 
        'protocol' => 'smtp', 
        'smtp_host' => 'ssl://smtp.googlemail.com', 
        'smtp_port' => 465, 
        'smtp_user' => 'mail.imojenpay.com', 
        'smtp_pass' => ''
        );        
         $from_email = "imojenpay@imojenpay.com"; 
         $to_email = $email; 
   
         //Load email library 
         $this->load->library('email',$config); 
   
         $this->email->from($from_email, 'Dotdev'); 
         $this->email->to($to_email);
         $this->email->subject('Hr Syatem'); 
         $message    =  "Your Login Email:"."$email";
         $message   .=  "Your Password :"."$pass_hash"; 
         $this->email->message($message); 
   
         //Send mail 
         if($this->email->send()){ 
            $this->session->set_flashdata('feedback','Kindly check your email To reset your password');
         }
         else {
         $this->session->set_flashdata("feedback","Error in sending Email."); 
         }          
    }
    public function Inactive_Employee(){
        $data['invalidem'] = $this->employee_model->getInvalidUser();
        $this->load->view('backend/invalid_user',$data);
    }
}